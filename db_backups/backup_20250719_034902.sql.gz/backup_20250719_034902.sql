-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: s1
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` varchar(36) NOT NULL,
  `relationId` varchar(100) DEFAULT '',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `inviteCode` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crawler_material`
--

DROP TABLE IF EXISTS `crawler_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crawler_material` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `keywords` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `suffix` varchar(20) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_ff086089f20f7866c501c3fb37b` (`uploaderId`),
  CONSTRAINT `FK_ff086089f20f7866c501c3fb37b` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crawler_material`
--

LOCK TABLES `crawler_material` WRITE;
/*!40000 ALTER TABLE `crawler_material` DISABLE KEYS */;
/*!40000 ALTER TABLE `crawler_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_model`
--

DROP TABLE IF EXISTS `custom_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_model` (
  `id` varchar(36) NOT NULL,
  `thumbnail` varchar(1000) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` json DEFAULT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `keywords` varchar(200) DEFAULT '',
  `name` varchar(200) DEFAULT '',
  `description` varchar(2000) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `FK_b93d0ec028411c5af74373785bf` (`uploaderId`),
  CONSTRAINT `FK_b93d0ec028411c5af74373785bf` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_model`
--

LOCK TABLES `custom_model` WRITE;
/*!40000 ALTER TABLE `custom_model` DISABLE KEYS */;
INSERT INTO `custom_model` VALUES ('14d60b27-8016-48f7-b07d-e231fb14d78d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735025897_1s_1752735025876.png','2025-07-17 06:49:44','2025-07-17 06:49:44','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 2.241230769230769, \"position\": {\"x\": 0, \"y\": 6.123233995736766e-17, \"z\": 1}, \"rotation\": {\"x\": -6.123233995736766e-17, \"y\": 0, \"z\": 0}}, \"decals\": [{\"id\": \"f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa\", \"size\": {\"x\": 0.15, \"y\": 0.14546703296703295, \"z\": 0.15}, \"isDraft\": false, \"position\": {\"x\": 0.12344464042314553, \"y\": 0.2021740999600512, \"z\": 0.17646224064715704}, \"rotation\": {\"x\": -0.3500396601731667, \"y\": 0.06858354280822368, \"z\": 0.025013188070924397}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 15, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}, \"selectedAngles\": []}',5,'模型,素材,78e6a739-70c5-4b32-84d8-0ee955f664e0,f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa','模型_78e6a739-70c5-4b32-84d8-0ee955f664e0_素材_f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa','基于设计模型 78e6a739-70c5-4b32-84d8-0ee955f664e0 和素材 f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa 生成的模型'),('23c8f169-d1de-4727-91be-268deecbfdc7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735033987_1s_1752735033957.png','2025-07-17 06:49:53','2025-07-17 06:49:53','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 2.241230769230769, \"position\": {\"x\": -0.020469, \"y\": -0.000973, \"z\": 0.999435}, \"rotation\": {\"x\": 0.0009735497482048712, \"y\": -0.020477698990456053, \"z\": 0.000019934671702198236}}, \"decals\": [{\"id\": \"f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa\", \"size\": {\"x\": 0.37, \"y\": 0.35881868131868133, \"z\": 0.37}, \"isDraft\": false, \"position\": {\"x\": 0.017847036607316923, \"y\": 0.16576524833668538, \"z\": 0.1822897481292026}, \"rotation\": {\"x\": -0.22280342281756707, \"y\": -0.009498081000708805, \"z\": -0.002151895957707533}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 37, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}, \"selectedAngles\": []}',5,'模型,素材,51284618-fd43-437c-a5fd-da0d53fc8a91,f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa','模型_51284618-fd43-437c-a5fd-da0d53fc8a91_素材_f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa','基于设计模型 51284618-fd43-437c-a5fd-da0d53fc8a91 和素材 f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa 生成的模型'),('51284618-fd43-437c-a5fd-da0d53fc8a91','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752733367504_1s_1752733367478.png','2025-07-17 06:22:07','2025-07-17 06:22:07','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.7784770295783512, \"position\": {\"x\": 0.04920907525679885, \"y\": 0.17390451112249558, \"z\": 1.0369999657284577}, \"rotation\": {\"x\": -0.16615355468236204, \"y\": 0.046765665929670894, \"z\": 0.007839565945412429}}, \"decals\": [{\"id\": \"098c0285-e5b1-4fbe-a2bf-075eeececb85\", \"size\": {\"x\": 0.37, \"y\": 0.24666666666666667, \"z\": 0.37}, \"isDraft\": false, \"position\": {\"x\": 0.017847036607316923, \"y\": 0.16576524833668538, \"z\": 0.1822897481292026}, \"rotation\": {\"x\": -0.22280342281756707, \"y\": -0.009498081000708805, \"z\": -0.002151895957707533}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 37, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}, \"selectedAngles\": []}',5,NULL,'正前方大logo白色T恤',NULL),('78e6a739-70c5-4b32-84d8-0ee955f664e0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752733596499_1s_1752733596476.png','2025-07-17 06:25:56','2025-07-17 06:25:56','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.718153846153846, \"position\": {\"x\": 0.13377773821482916, \"y\": 0.2296759144910879, \"z\": 1.075681251215039}, \"rotation\": {\"x\": -0.21035796790591776, \"y\": 0.12102966982187403, \"z\": 0.025773104784160915}}, \"decals\": [{\"id\": \"098c0285-e5b1-4fbe-a2bf-075eeececb85\", \"size\": {\"x\": 0.15, \"y\": 0.1, \"z\": 0.15}, \"isDraft\": false, \"position\": {\"x\": 0.12344464042314553, \"y\": 0.2021740999600512, \"z\": 0.17646224064715704}, \"rotation\": {\"x\": -0.3500396601731667, \"y\": 0.06858354280822368, \"z\": 0.025013188070924397}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 15, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}, \"selectedAngles\": []}',5,NULL,'左胸口小logo白色T恤',NULL),('c1571f27-5d13-4c13-82d4-ebe9a72570d7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735029811_1s_1752735029789.png','2025-07-17 06:49:49','2025-07-17 06:49:49','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 2.241230769230769, \"position\": {\"x\": -0.027507, \"y\": -0.030408, \"z\": 0.994801}, \"rotation\": {\"x\": 0.030557402808653208, \"y\": -0.027630813933213424, \"z\": 0.0008444811420861616}}, \"decals\": [{\"id\": \"32a308d9-71ed-46b5-a89d-ae35b2bc8341\", \"size\": {\"x\": 0.37, \"y\": 0.37, \"z\": 0.37}, \"isDraft\": false, \"position\": {\"x\": 0.017847036607316923, \"y\": 0.16576524833668538, \"z\": 0.1822897481292026}, \"rotation\": {\"x\": -0.22280342281756707, \"y\": -0.009498081000708805, \"z\": -0.002151895957707533}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 37, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}, \"selectedAngles\": []}',5,'模型,素材,51284618-fd43-437c-a5fd-da0d53fc8a91,32a308d9-71ed-46b5-a89d-ae35b2bc8341','模型_51284618-fd43-437c-a5fd-da0d53fc8a91_素材_32a308d9-71ed-46b5-a89d-ae35b2bc8341','基于设计模型 51284618-fd43-437c-a5fd-da0d53fc8a91 和素材 32a308d9-71ed-46b5-a89d-ae35b2bc8341 生成的模型'),('c8629170-471c-4db1-81d4-e9ccc2d54aba','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735021700_1s_1752735021679.png','2025-07-17 06:49:41','2025-07-17 06:49:41','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 2.241230769230769, \"position\": {\"x\": 0, \"y\": 6.123233995736766e-17, \"z\": 1}, \"rotation\": {\"x\": -6.123233995736766e-17, \"y\": 0, \"z\": 0}}, \"decals\": [{\"id\": \"32a308d9-71ed-46b5-a89d-ae35b2bc8341\", \"size\": {\"x\": 0.15, \"y\": 0.15, \"z\": 0.15}, \"isDraft\": false, \"position\": {\"x\": 0.12344464042314553, \"y\": 0.2021740999600512, \"z\": 0.17646224064715704}, \"rotation\": {\"x\": -0.3500396601731667, \"y\": 0.06858354280822368, \"z\": 0.025013188070924397}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 15, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}, \"selectedAngles\": []}',5,'模型,素材,78e6a739-70c5-4b32-84d8-0ee955f664e0,32a308d9-71ed-46b5-a89d-ae35b2bc8341','模型_78e6a739-70c5-4b32-84d8-0ee955f664e0_素材_32a308d9-71ed-46b5-a89d-ae35b2bc8341','基于设计模型 78e6a739-70c5-4b32-84d8-0ee955f664e0 和素材 32a308d9-71ed-46b5-a89d-ae35b2bc8341 生成的模型');
/*!40000 ALTER TABLE `custom_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `design_request`
--

DROP TABLE IF EXISTS `design_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `design_request` (
  `id` varchar(36) NOT NULL,
  `description` text,
  `userId` int(11) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(100) NOT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_4ba6d530242079590e99e5283b0` (`userId`),
  CONSTRAINT `FK_4ba6d530242079590e99e5283b0` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_request`
--

LOCK TABLES `design_request` WRITE;
/*!40000 ALTER TABLE `design_request` DISABLE KEYS */;
INSERT INTO `design_request` VALUES ('891a5c29-ad17-4c24-b0ff-2788e8eaccad','白色T恤，粉色图案haha1',NULL,'2025-06-15 13:35:26','2025-06-15 13:35:26','设计一个情侣衫','18742539196','265@qq.com'),('d50ad493-bf09-422f-9fdc-e885cb22837b','1111',NULL,'2025-07-08 23:51:55','2025-07-08 23:51:55','111','','');
/*!40000 ALTER TABLE `design_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `draft`
--

DROP TABLE IF EXISTS `draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draft` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `type` varchar(50) DEFAULT 'image',
  `uploaderId` int(11) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `customModelId` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_a5fd75a51e6c58a65a8a16588f3` (`uploaderId`),
  KEY `FK_fb1f03e474a0c0ed127e189ffe8` (`customModelId`),
  CONSTRAINT `FK_a5fd75a51e6c58a65a8a16588f3` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_fb1f03e474a0c0ed127e189ffe8` FOREIGN KEY (`customModelId`) REFERENCES `custom_model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draft`
--

LOCK TABLES `draft` WRITE;
/*!40000 ALTER TABLE `draft` DISABLE KEYS */;
INSERT INTO `draft` VALUES ('17f81fab-b6db-43da-b32c-5798d3b3d0de','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735026788_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-07-17 06:49:46','2025-07-17 06:50:27','14d60b27-8016-48f7-b07d-e231fb14d78d'),('ccc01b62-d892-4177-b194-78ba4743ccbf','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735022898_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-07-17 06:49:42','2025-07-17 06:50:23','c8629170-471c-4db1-81d4-e9ccc2d54aba'),('dc3a7d28-18b6-4130-87b8-1ddc8a924dd1','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735035396_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-07-17 06:49:54','2025-07-17 06:50:36','23c8f169-d1de-4727-91be-268deecbfdc7'),('e478341f-d63a-4055-a5ab-8e53a9dbad54','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752755126347_1s_1752755126298.png','模型截图','','image',5,NULL,'2025-07-17 12:25:28','2025-07-17 12:25:28','c1571f27-5d13-4c13-82d4-ebe9a72570d7'),('fbe3ce81-b9db-4229-90a9-940862d762c1','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752735030844_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-07-17 06:49:50','2025-07-17 06:50:31','c1571f27-5d13-4c13-82d4-ebe9a72570d7');
/*!40000 ALTER TABLE `draft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` varchar(36) NOT NULL,
  `url` varchar(200) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `size` varchar(100) DEFAULT '',
  `rawName` varchar(100) DEFAULT '',
  `type` varchar(100) DEFAULT '',
  `thumbnail` varchar(255) DEFAULT '',
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `uploaderId` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT '',
  `keywords` varchar(100) DEFAULT '',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_e529b53c18487a72385a6a440f0` (`uploaderId`),
  CONSTRAINT `FK_e529b53c18487a72385a6a440f0` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `font_template`
--

DROP TABLE IF EXISTS `font_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `font_template` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `key` varchar(1000) DEFAULT '',
  `thumbnail` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `category` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `keywords` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `FK_3060138a40ac893aa984c082390` (`uploaderId`),
  CONSTRAINT `FK_3060138a40ac893aa984c082390` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `font_template`
--

LOCK TABLES `font_template` WRITE;
/*!40000 ALTER TABLE `font_template` DISABLE KEYS */;
INSERT INTO `font_template` VALUES ('304e1f30-51d3-4f0a-848e-6537d4235907','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749114110062_1s_Heart%20Breaking%20Bad.otf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749114109860_1s_1749114109857.png','绝命毒师字体','','',5,0,'{}','2025-06-05 09:01:49','2025-06-20 02:34:05',''),('60cc1615-f567-40d0-845c-a4cd55c6b50f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748862915884_1s_ChillRoundM.otf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748862913749_1s_1748862913722.png','ChillRoundM.otf','','',5,0,'{}','2025-06-02 11:15:25','2025-06-02 11:15:25',''),('643198bb-f1a2-47ef-8b76-2498bd270915','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750677127463_1s_cole.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750677126803_1s_1750677126801.png','可口可乐字体','','',5,0,'{}','2025-06-23 11:11:54','2025-06-23 11:11:54',''),('68511302-251a-46ed-a6c8-0b18fcc6dfc7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750371495388_1s_YeZiGongChangTangYingHei-2.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750371492084_1s_1750371492082.png','YeZiGongChangTangYingHei-2.ttf','','',5,0,'{}','2025-06-19 22:18:54','2025-06-19 22:18:54',''),('76f13f06-a0fd-48e2-904d-02d3d9e698f1','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750386527170_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750386526556_1s_1750386526537.png','ZCOOLKuaiLe-Regular.ttf','','字体描述',5,0,'{}','2025-06-20 02:28:47','2025-06-20 02:36:04','通用,日文'),('bf4dd2d7-eaf0-4e8f-aadb-60cb41af4584','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326084125_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326084020_1s_1750326084017.png','ZCOOLKuaiLe-Regular.ttf','','',5,0,'{}','2025-06-19 09:41:20','2025-06-19 09:41:20',''),('da49f532-b2a6-467f-bba4-61b2f454cd26','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326056038_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326055887_1s_1750326055885.png','ZCOOLKuaiLe-Regular.ttf','','',5,0,'{}','2025-06-19 09:40:53','2025-06-19 09:40:53',''),('e324761a-b89a-45fe-b02c-ae5ee9880732','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326031579_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326031254_1s_1750326031251.png','ZCOOLKuaiLe-Regular.ttf','','',5,0,'{}','2025-06-19 09:40:29','2025-06-19 09:40:29',''),('ea6009e9-1c28-4436-9538-bd8abb53f78d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750372032553_1s_YeZiGongChangTangYingHei-2.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750372030437_1s_1750372030434.png','YeZiGongChangTangYingHei-2.ttf','','',5,0,'{}','2025-06-19 22:27:45','2025-06-19 22:27:45','');
/*!40000 ALTER TABLE `font_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(1000) DEFAULT '',
  `type` varchar(1000) DEFAULT '',
  `price` decimal(10,2) NOT NULL,
  `salePrice` decimal(10,2) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT '0',
  `specifications` varchar(1000) DEFAULT '',
  `tags` varchar(1000) DEFAULT '',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isLimitedEdition` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否绝版：0-否，1-是',
  `images` json DEFAULT NULL,
  `code` varchar(50) NOT NULL DEFAULT '',
  `isPublish` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发布：false-未发布，true-已发布',
  `keywords` varchar(1000) DEFAULT '',
  `videos` json DEFAULT NULL,
  `customModelId` varchar(255) DEFAULT NULL COMMENT '关联定制模型ID',
  PRIMARY KEY (`id`),
  KEY `FK_9c64ca04cbf59ee888a20228d0b` (`customModelId`),
  CONSTRAINT `FK_9c64ca04cbf59ee888a20228d0b` FOREIGN KEY (`customModelId`) REFERENCES `custom_model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('07a7cbb8-8cf1-499b-8268-38371bab1526','时尚苹果图案T恤','这款时尚苹果图案T恤，采用高品质纯棉材质，柔软舒适，透气性佳，适合日常穿着。独特的苹果图案设计，简约而不失个性，彰显您的独特品味。无论是休闲出行还是朋友聚会，都能让您成为焦点。经典白色搭配，百搭易穿，轻松驾驭各种风格。','自定义模型',0.00,NULL,0,'','',1,NULL,'2025-07-17 07:52:57','2025-07-18 06:10:24',0,'[]','',1,'苹果图案T恤, 白色T恤, 纯棉T恤, 时尚T恤, 舒适T恤, 个性设计, 日常穿着, 百搭T恤, 经典白色, 高品质T恤',NULL,'23c8f169-d1de-4727-91be-268deecbfdc7'),('c2227672-a65c-404d-b36a-a1b759cf2225','T-shirt','A white T-shirt featuring a prominent purple logo on the back.','自定义模型',0.00,NULL,0,'','',1,NULL,'2025-07-17 13:16:27','2025-07-18 06:10:21',0,'[]','',1,'white t-shirt, purple logo, clothing, apparel',NULL,'c1571f27-5d13-4c13-82d4-ebe9a72570d7');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_model`
--

DROP TABLE IF EXISTS `product_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_model` (
  `id` varchar(36) NOT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `price` varchar(1000) DEFAULT NULL,
  `url` varchar(1000) DEFAULT NULL,
  `keywords` varchar(1000) DEFAULT '',
  `thumbnail` varchar(1000) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_model`
--

LOCK TABLES `product_model` WRITE;
/*!40000 ALTER TABLE `product_model` DISABLE KEYS */;
INSERT INTO `product_model` VALUES ('0406ffff-add7-49c4-a7d4-dff1e83d00b4','白色T恤','这是一件简洁的白色短袖T恤，设计经典，适合各种场合穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748865053369_1s_tshirt.glb','白色 T恤 短袖 休闲 时尚','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748865051768_1s_1748865051763.png',NULL,'2025-06-02 11:51:28','2025-07-16 05:06:11'),('0872a0a2-8287-41e4-9359-631f12d5f0b6','长袖T恤','这是一件白色主体搭配浅蓝色袖子的长袖T恤，设计简洁时尚。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110901040_1s_t-shirt_-_lengan_panjang.glb','长袖T恤, 白色, 浅蓝色袖子, 简洁设计, 时尚','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110900613_1s_1749110900611.png',NULL,'2025-06-05 08:08:25','2025-07-15 05:32:44'),('2de7c2db-0bb6-4be7-8945-a1bb44107dea','白色T恤','这是一件简洁的白色短袖T恤，设计经典，适合各种场合穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110632843_1s_tshirt%20%284%29.glb','白色T恤, 短袖, 经典设计, 休闲服装','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110631279_1s_1749110631276.png',NULL,'2025-06-05 08:03:52','2025-07-16 05:06:40'),('3d8269e9-8019-47f0-b933-7fc50a1a2a68','渔夫帽','这是一款简约风格的渔夫帽模型，颜色为浅米色，设计简洁，适合日常佩戴。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112006658_1s_white_baseball_cap.glb','渔夫帽, 浅米色, 简约, 日常佩戴','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112006141_1s_1749112006139.png',NULL,'2025-06-05 08:26:47','2025-07-14 22:16:54'),('4c41551e-e476-464c-985c-6848610bfc80','白色T恤','这是一件简洁的白色T恤，设计经典，适合各种场合穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110306767_1s_tshirt%20%282%29.glb','白色T恤,经典设计,日常穿着','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110306624_1s_1749110306621.png',NULL,'2025-06-05 07:58:28','2025-07-15 05:32:31'),('668b4da6-453d-4613-a1f9-88aca43518a7','白色T恤','这是一件简洁的白色短袖T恤，设计经典，适合各种场合穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110776396_1s_tshirt_with_etecet.glb','白色T恤, 短袖, 经典设计, 休闲服装','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110775972_1s_1749110775969.png',NULL,'2025-06-05 08:06:18','2025-07-16 05:06:56'),('6e803cf1-8677-42a5-aa1d-6ff3733bc0e6','白色T恤','这是一件简洁的白色短袖T恤，设计经典，适合日常穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749106430191_1s_tshirt.glb','白色T恤, 短袖, 日常穿着, 经典设计','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749106429405_1s_1749106429397.png',NULL,'2025-06-05 06:53:51','2025-07-14 22:52:13'),('8fc642be-525f-43c5-b106-d2abb9ba3fe3','白色T恤','这是一件简洁的白色短袖T恤，设计经典，适合各种场合穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110632896_1s_tshirt_with_etecet.glb','白色 T恤 短袖 休闲 时尚','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110631291_1s_1749110631289.png',NULL,'2025-06-05 08:03:55','2025-07-16 05:06:49'),('9d0b7444-da1f-4996-8d6c-56da3e653793','白色运动衫','这是一件白色的短袖运动衫，领口和袖口有浅蓝色的装饰，设计简洁时尚，适合运动或休闲穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110945870_1s_t-shirt_polo_lengan_pendek.glb','白色, 运动衫, 短袖, 浅蓝色装饰, 休闲, 运动','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110945719_1s_1749110945715.png',NULL,'2025-06-05 08:09:10','2025-07-14 23:08:48'),('a101126e-a6b6-4f62-a458-ac47fd363e36','白色T恤','这是一件简洁的白色短袖T恤，设计经典，适合各种场合穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110337967_1s_tshirt%20%283%29.glb','白色T恤, 短袖, 经典设计, 休闲服装','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110337846_1s_1749110337844.png',NULL,'2025-06-05 07:59:04','2025-07-16 05:06:20'),('cc0b92af-b04a-4ecf-a1b8-67745be6a7c9','T恤模型','这是一个简单的白色T恤3D模型，设计简洁，适合用于各种场景的展示和编辑。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110371901_1s_tshirt%20%284%29.glb','T恤,白色,3D模型,服装,简约设计','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110371779_1s_1749110371776.png',NULL,'2025-06-05 07:59:31','2025-07-16 05:06:32'),('f6acae3e-3059-42e2-8b14-c7aac16c9f0e','黑色礼帽','这是一款经典的黑色礼帽模型，设计简洁，线条流畅，适合各种正式或休闲场合。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749111659784_1s_low_poly_stylized_hat.glb','黑色, 礼帽, 经典, 简洁, 正式, 休闲','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749111659033_1s_1749111659032.png',NULL,'2025-06-05 08:21:15','2025-07-14 22:20:59'),('f8a17d77-d5ca-4052-9621-47a1f1706019','Polo衫','这是一件深色的短袖Polo衫，设计简洁，适合日常穿着或休闲场合。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749109210933_1s_tshirt%20%281%29.glb','Polo衫, 短袖, 深色, 休闲, 日常穿着','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749109210264_1s_1749109210262.png',NULL,'2025-06-05 07:40:24','2025-07-14 22:52:25'),('ff05c413-f430-4f1b-9c47-d4b6699b12e5','白色T恤','这是一件简洁的白色短袖T恤，设计简约，适合日常穿着。',NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110840145_1s_tshirt_mockup_brock_creative_final.glb','白色 T恤 短袖 简约 休闲','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110839739_1s_1749110839734.png',NULL,'2025-06-05 08:07:29','2025-07-16 05:07:05');
/*!40000 ALTER TABLE `product_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psd_template`
--

DROP TABLE IF EXISTS `psd_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psd_template` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `key` varchar(1000) DEFAULT '',
  `thumbnail` json DEFAULT NULL,
  `name` varchar(1000) DEFAULT '',
  `category` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_fa6f703fc301e39ef3215c8710c` (`uploaderId`),
  CONSTRAINT `FK_fa6f703fc301e39ef3215c8710c` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psd_template`
--

LOCK TABLES `psd_template` WRITE;
/*!40000 ALTER TABLE `psd_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `psd_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relation`
--

DROP TABLE IF EXISTS `relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `followerId` int(11) NOT NULL,
  `followedId` int(11) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relation`
--

LOCK TABLES `relation` WRITE;
/*!40000 ALTER TABLE `relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sentences`
--

DROP TABLE IF EXISTS `sentences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sentences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sentences`
--

LOCK TABLES `sentences` WRITE;
/*!40000 ALTER TABLE `sentences` DISABLE KEYS */;
INSERT INTO `sentences` VALUES (18,'落魄谷中寒风吹，春秋蝉鸣少年归','2025-07-09 07:38:18.565595','2025-07-09 07:38:18.565595',''),(19,'月光洒在静谧的湖面上宛如一地碎银','2025-07-18 15:53:34.580538','2025-07-18 15:53:34.580538',''),(20,'生命不是要超越别人而是要超越自己','2025-07-18 15:53:46.088638','2025-07-18 15:53:46.088638',''),(21,'月光洒在静谧的湖面上，仿佛为大地披上了一层银纱。','2025-07-18 15:55:37.350099','2025-07-18 15:55:37.350099','描绘月光下湖面的宁静与美丽。'),(22,'岁月静好，只因有你相伴。','2025-07-18 15:55:47.748769','2025-07-18 15:55:47.748769','表达对陪伴者的感激与珍惜。'),(23,'生命不是要超越别人，而是要超越自己。','2025-07-18 15:56:01.835409','2025-07-18 15:56:01.835409','鼓励自我提升的励志名言。'),(24,'成功是不断失败，却依然保持热情。','2025-07-18 15:56:26.073155','2025-07-18 15:56:26.073155','强调坚持与热情在成功道路上的重要性。'),(25,'希望是好事，也许是人间至善，而美好的事永不消逝。','2025-07-18 15:56:41.480132','2025-07-18 15:56:41.480132','表达了希望的力量和永恒的价值。'),(26,'钢铁是在烈火与骤冷中铸造而成的。','2025-07-18 15:57:50.594377','2025-07-18 15:57:50.594377','强调坚韧不拔的意志和顽强的奋斗精神。'),(27,'月光洒在湖面上，仿佛为黑夜披上了一层银纱。','2025-07-18 16:02:05.760273','2025-07-18 16:02:05.760273','描绘夜晚湖面的静谧与美丽。'),(28,'明月松间照，清泉石上流。','2025-07-18 16:02:21.290223','2025-07-18 16:02:21.290223','描绘了月光下松林和山泉的宁静美景。'),(29,'明月松间照，清泉石上流。','2025-07-18 16:02:41.812835','2025-07-18 16:02:41.812835','王维《山居秋暝》中的名句，描绘了宁静优美的自然景色。'),(30,'云想衣裳花想容，春风拂槛露华浓。','2025-07-18 16:04:06.817324','2025-07-18 16:04:06.817324','描绘了如云的衣裳和如花的容貌，在春风中显得更加娇艳动人。');
/*!40000 ALTER TABLE `sentences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sticker`
--

DROP TABLE IF EXISTS `sticker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sticker` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `keywords` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `group` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `key` varchar(1000) DEFAULT '',
  `isTexture` tinyint(4) NOT NULL DEFAULT '0',
  `suffix` varchar(20) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `FK_63f76d2f8fb3b56b4b10264d398` (`uploaderId`),
  CONSTRAINT `FK_63f76d2f8fb3b56b4b10264d398` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sticker`
--

LOCK TABLES `sticker` WRITE;
/*!40000 ALTER TABLE `sticker` DISABLE KEYS */;
INSERT INTO `sticker` VALUES ('098c0285-e5b1-4fbe-a2bf-075eeececb85','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752636085431_1s_3a68cb65-52f8-4296-bb1d-15d2f57c72e6','设计, 工作室, 缝纫机, 模特, 创意, 艺术, 工具, 植物, 光效','创意设计工作室','','这张图片展示了一个充满创意的设计工作室场景。画面中有一个巨大的缝纫机，上面坐着一个正在使用笔记本电脑的女性。旁边有一个穿着红色帽子和白色上衣的人物，正在为一个穿着黄色连衣裙的模特绘制图案。周围摆放着各种设计工具和材料，如尺子、铅笔、剪刀和线轴，背景中还有一些装饰性的植物和闪光效果，整体氛围充满了艺术和创造力。',NULL,0,NULL,'2025-07-16 03:20:48','2025-07-16 09:00:07','',0,'jpg'),('32a308d9-71ed-46b5-a89d-ae35b2bc8341','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752733616933_1s_3a5aa91e-62b8-4bcf-87ff-99b852fceea1','衣, 紫色, logo, 汉字','衣字logo','','这是一个紫色背景的logo，中间有一个白色的汉字“衣”。背景颜色从左上角到右下角逐渐变浅。',NULL,0,NULL,'2025-07-17 06:26:16','2025-07-17 06:27:09','',0,'png'),('f0b85b4c-dcca-4e53-9ad9-9898fa1cb4fa','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1752651252829_1s_ab0ba647-cf13-4efe-a6c9-5bec6bc3e9d5','苹果, logo, 金属光泽, 银色, 棋盘格背景','苹果logo','','这是一张展示苹果公司logo的图片，logo呈现出一个被咬了一口的苹果形状，表面具有金属光泽，颜色为银色，背景为透明的棋盘格。',NULL,0,NULL,'2025-07-16 07:33:33','2025-07-16 08:59:42','',0,'jpg');
/*!40000 ALTER TABLE `sticker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `phone` bigint(20) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `isAdmin` tinyint(4) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `avatar` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (5,'jackie','jackie',NULL,NULL,NULL,NULL,NULL,'$2a$10$tPfIAPO/N1OUoXF4RzoTbOG.BAE.dyYTKiyJmq9Po3g685I74GUBu','{}','','','2025-05-29 23:49:04','2025-06-05 10:45:15');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-19 11:48:58
