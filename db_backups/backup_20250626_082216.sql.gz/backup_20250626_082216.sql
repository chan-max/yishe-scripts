-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: s1
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` varchar(36) NOT NULL,
  `relationId` varchar(100) DEFAULT '',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `inviteCode` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_model`
--

DROP TABLE IF EXISTS `custom_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_model` (
  `id` varchar(36) NOT NULL,
  `thumbnail` varchar(1000) DEFAULT NULL,
  `keywords` varchar(100) DEFAULT '',
  `name` varchar(100) DEFAULT '',
  `description` varchar(100) DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` json DEFAULT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_b93d0ec028411c5af74373785bf` (`uploaderId`),
  CONSTRAINT `FK_b93d0ec028411c5af74373785bf` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_model`
--

LOCK TABLES `custom_model` WRITE;
/*!40000 ALTER TABLE `custom_model` DISABLE KEYS */;
INSERT INTO `custom_model` VALUES ('073b03ce-4980-4d73-9882-c50c0bfcf41d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750478593102_1s_1750478593082.png',NULL,NULL,NULL,'2025-06-21 04:03:13','2025-06-21 04:03:13','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.5453216374269005, \"position\": {\"x\": -0.06605465302411331, \"y\": 0.22436201126463565, \"z\": 0.888096564469648}, \"rotation\": {\"x\": -0.24745472475754024, \"y\": -0.07198755052210173, \"z\": -0.01816868831395385}}, \"decals\": [{\"id\": \"e504494b-5905-4dd3-a106-424466f843c7\", \"size\": {\"x\": 0.2, \"y\": 0.17265624999999998, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.00890836669719091, \"y\": 0.18985300847619435, \"z\": 0.21810730907758064}, \"rotation\": {\"x\": -0.08944970256564798, \"y\": -0.012519183717283324, \"z\": -0.0011228037470078945}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('304c8ca4-0b44-43f0-9e4a-07baeaddf78d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749247343864_1s_1749247343843.png','','','','2025-06-06 22:02:29','2025-06-06 22:02:29','{\"modelInfo\": {\"state\": {\"material\": {\"color\": \"#FF0000\", \"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": {\"id\": \"9162c5f9-2f26-4151-8649-dfeac74fd0cf\", \"url\": \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602150856.png\", \"meta\": null, \"name\": \"\", \"isPublic\": false, \"keywords\": \"\", \"uploader\": {\"name\": \"jackie\", \"email\": \"\", \"account\": \"jackie\", \"isAdmin\": null}, \"createTime\": \"2025-06-04 11:24:24\", \"updateTime\": \"2025-06-04 11:24:24\", \"description\": \"\"}, \"textureRepeat\": 2}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.9098591549295776, \"position\": {\"x\": 0.5941611148038901, \"y\": -0.24239172583861068, \"z\": 1.0746774829736994}, \"rotation\": {\"x\": 0.2218363020395311, \"y\": 0.4946110879219121, \"z\": -0.1066590982467131}}, \"decals\": [], \"isDarkMode\": false, \"baseModelId\": \"085d6c49-d882-4af0-a02a-d0c109109fd0\", \"canvasBgColor\": 0, \"canvasBgOpacity\": \"0\"}}',5),('3c0c1cec-5a3d-4dc2-b33f-1dfd25fb097b','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750479124075_1s_1750479124022.png',NULL,'白色带纹理的 react T恤',NULL,'2025-06-21 04:12:08','2025-06-21 04:12:08','{\"modelInfo\": {\"state\": {\"material\": {\"color\": \"#ffffff\", \"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": {\"id\": \"ac929005-3a07-4c8a-95db-6f79081e3494\", \"url\": \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750124735570_1s_dense-rattan-599-mm-architextures.jpg\", \"meta\": null, \"name\": \"\", \"group\": \"\", \"isPublic\": false, \"keywords\": \"\", \"uploader\": {\"name\": \"jackie\", \"email\": \"\", \"account\": \"jackie\", \"isAdmin\": null}, \"isTexture\": true, \"createTime\": \"2025-06-17 09:45:35\", \"updateTime\": \"2025-06-17 17:35:05\", \"description\": \"\"}, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.5116959064327486, \"position\": {\"x\": 0, \"y\": 0.17955796747788774, \"z\": 0.941848684974788}, \"rotation\": {\"x\": -0.18838360552981545, \"y\": 0, \"z\": 0}}, \"decals\": [{\"id\": \"919878e7-0d5f-45e8-95be-95dd0c5b7074\", \"size\": {\"x\": 0.2, \"y\": 0.2, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.1151601397730263, \"y\": 0.17318656679044253, \"z\": 0.20422901234861313}, \"rotation\": {\"x\": -0.011901050277689585, \"y\": 0.3461461780700943, \"z\": 0.004037898655621832}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('421a51ed-1163-4b6f-8585-aaf6b985ee83','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750170444706_1s_1750170444629.png','','','','2025-06-17 14:27:33','2025-06-17 14:27:33','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": {\"id\": \"60722054-db93-452f-96b8-337b5379d7ac\", \"url\": \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750123258704_1s_TCom_Fabric_Wool7_header.jpg\", \"meta\": null, \"name\": \"\", \"isPublic\": false, \"keywords\": \"\", \"uploader\": {\"name\": \"jackie\", \"email\": \"\", \"account\": \"jackie\", \"isAdmin\": null}, \"createTime\": \"2025-06-17 09:21:00\", \"updateTime\": \"2025-06-17 22:20:24\", \"description\": \"\"}, \"textureRepeat\": 13}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.4281767955801106, \"position\": {\"x\": -0.06812613469814825, \"y\": 0.3088568970254122, \"z\": 0.5972028009514001}, \"rotation\": {\"x\": -0.4772910814015578, \"y\": -0.1009819527559222, \"z\": -0.05208921770989303}}, \"decals\": [], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('47c094ae-8da1-47a4-a4db-15f193d04233','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750478616122_1s_1750478616103.png','程序员,白色,大logo','vue T恤','vue 很棒','2025-06-21 04:03:37','2025-06-21 04:04:26','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.5453216374269005, \"position\": {\"x\": -0.06605465302411331, \"y\": 0.22436201126463565, \"z\": 0.888096564469648}, \"rotation\": {\"x\": -0.24745472475754024, \"y\": -0.07198755052210173, \"z\": -0.01816868831395385}}, \"decals\": [{\"id\": \"e504494b-5905-4dd3-a106-424466f843c7\", \"size\": {\"x\": 0.2, \"y\": 0.17265624999999998, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.00890836669719091, \"y\": 0.18985300847619435, \"z\": 0.21810730907758064}, \"rotation\": {\"x\": -0.08944970256564798, \"y\": -0.012519183717283324, \"z\": -0.0011228037470078945}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('7aa46062-3264-4595-91f3-b8983e4cb42e','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750479042088_1s_1750479042046.png',NULL,'白色带纹理的 react T恤',NULL,'2025-06-21 04:10:44','2025-06-21 04:10:44','{\"modelInfo\": {\"state\": {\"material\": {\"color\": \"#ffffff\", \"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": {\"id\": \"ac929005-3a07-4c8a-95db-6f79081e3494\", \"url\": \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750124735570_1s_dense-rattan-599-mm-architextures.jpg\", \"meta\": null, \"name\": \"\", \"group\": \"\", \"isPublic\": false, \"keywords\": \"\", \"uploader\": {\"name\": \"jackie\", \"email\": \"\", \"account\": \"jackie\", \"isAdmin\": null}, \"isTexture\": true, \"createTime\": \"2025-06-17 09:45:35\", \"updateTime\": \"2025-06-17 17:35:05\", \"description\": \"\"}, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.5116959064327486, \"position\": {\"x\": 0, \"y\": 0.17955796747788774, \"z\": 0.941848684974788}, \"rotation\": {\"x\": -0.18838360552981545, \"y\": 0, \"z\": 0}}, \"decals\": [{\"id\": \"919878e7-0d5f-45e8-95be-95dd0c5b7074\", \"size\": {\"x\": 0.2, \"y\": 0.2, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.1151601397730263, \"y\": 0.17318656679044253, \"z\": 0.20422901234861313}, \"rotation\": {\"x\": -0.011901050277689585, \"y\": 0.3461461780700943, \"z\": 0.004037898655621832}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('9b3cd462-6cab-4d9e-a162-a990a31d9d95','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748952874141_1s_1748952874121.png','','','','2025-06-03 12:14:38','2025-06-03 12:14:38','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.4339080459770115, \"position\": {\"x\": 0.03641138968182691, \"y\": 0.289541732052294, \"z\": 0.7199303926302875}, \"rotation\": {\"x\": -0.38238442512733406, \"y\": 0.0468891295570412, \"z\": 0.018848736536358626}}, \"decals\": [{\"id\": \"1cd1566d-ac82-4473-b531-76f76fe95dc4\", \"size\": {\"x\": 0.2, \"y\": 0.2, \"z\": 0.2}, \"position\": {\"x\": 0.06178747423411285, \"y\": 0.1445040568881384, \"z\": 0.11481653070333532}, \"rotation\": {\"x\": -0.31348676551145016, \"y\": 0.009343250548662946, \"z\": 0.0030288076330977284}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\", \"canvasBgColor\": 0, \"canvasBgOpacity\": \"0\"}}',5),('9f02d962-bda7-4b1c-8569-ff04d4909b7f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750153912330_1s_1750153912242.png','','','','2025-06-17 09:51:51','2025-06-17 09:51:51','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.7619893428063944, \"position\": {\"x\": 0.13988040758373907, \"y\": 0.4494515129943008, \"z\": 0.6386000012671913}, \"rotation\": {\"x\": -0.6132768098213979, \"y\": 0.1772456913934195, \"z\": 0.12346353174264282}}, \"decals\": [{\"id\": \"bbe762cf-478e-4a5f-b3b2-2cba6fb885f7\", \"size\": {\"x\": 0.2, \"y\": 0.111605415860735, \"z\": 0.2}, \"position\": {\"x\": 0.0062140841157374855, \"y\": 0.10835829844522464, \"z\": 0.1451160770856295}, \"rotation\": {\"x\": 0.08963020564703489, \"y\": -0.031162935261866385, \"z\": 0.002800183448295322}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}, {\"id\": \"38394c2d-5ee8-4954-9b23-1498820dfce6\", \"size\": {\"x\": 0.2, \"y\": 0.1128254580520733, \"z\": 0.2}, \"position\": {\"x\": 0.002952120602103546, \"y\": -0.013061287179814585, \"z\": 0.14193469524483077}, \"rotation\": {\"x\": -0.02222141043975025, \"y\": -0.01276341246782574, \"z\": -0.00028366001011385667}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}, {\"id\": \"f5e23fdb-237c-400c-9a57-6546222ca04e\", \"size\": {\"x\": 0.2, \"y\": 0.2602910602910603, \"z\": 0.2}, \"position\": {\"x\": -0.008530684874426356, \"y\": 0.19166274609685313, \"z\": -0.1377566847021982}, \"rotation\": {\"x\": -2.979433205621064, \"y\": 0.00674715128892728, \"z\": 3.1404888559649966}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('abd8f472-9dcc-48ee-838a-62ea11f05158','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748867518769_1s_1748867518757.png','','','','2025-06-02 12:32:05','2025-06-02 12:32:05','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.7168508287292817, \"position\": {\"x\": 0, \"y\": 6.123233995736766e-17, \"z\": 1}, \"rotation\": {\"x\": -6.123233995736766e-17, \"y\": 0, \"z\": 0}}, \"decals\": [{\"id\": \"19045856-558b-406a-9e8e-b7ed7b8b5d2a\", \"size\": {\"x\": 0.2, \"y\": 0.2, \"z\": 0.2}, \"position\": {\"x\": 0.023169142119051658, \"y\": 0.04170445581429272, \"z\": 0.12918733580139416}, \"rotation\": {\"x\": -0.07809588451542793, \"y\": -0.06268362363891151, \"z\": -0.004902058541656536}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\", \"canvasBgColor\": 0, \"canvasBgOpacity\": \"0\"}}',NULL),('ad639e32-2d77-414b-a78f-ad96ee84ead9','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749774271731_1s_1749774271711.png','','','','2025-06-13 00:24:39','2025-06-13 00:24:39','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.6947513812154696, \"position\": {\"x\": -0.026195495655697808, \"y\": 0.3029301154493446, \"z\": 0.7066531648160942}, \"rotation\": {\"x\": -0.40498594163336366, \"y\": -0.03405797821438007, \"z\": -0.014596213219504628}}, \"decals\": [{\"id\": \"dae7cf23-df73-46a2-beeb-87806f5fab03\", \"size\": {\"x\": 0.2, \"y\": 0.19531981279251173, \"z\": 0.2}, \"position\": {\"x\": 0.005500523587312656, \"y\": 0.09852248495057504, \"z\": 0.1235923420625763}, \"rotation\": {\"x\": -0.15470083948253455, \"y\": 0.004479054879143354, \"z\": 0.0006984922177024978}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\"}}',5),('aed93f03-0d55-4f6e-8739-4bd99a7d24c5','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750478531513_1s_1750478531489.png','','','','2025-06-21 04:02:12','2025-06-21 04:02:12','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.5453216374269005, \"position\": {\"x\": -0.06605465302411331, \"y\": 0.22436201126463565, \"z\": 0.888096564469648}, \"rotation\": {\"x\": -0.24745472475754024, \"y\": -0.07198755052210173, \"z\": -0.01816868831395385}}, \"decals\": [{\"id\": \"e504494b-5905-4dd3-a106-424466f843c7\", \"size\": {\"x\": 0.2, \"y\": 0.17265624999999998, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.00890836669719091, \"y\": 0.18985300847619435, \"z\": 0.21810730907758064}, \"rotation\": {\"x\": -0.08944970256564798, \"y\": -0.012519183717283324, \"z\": -0.0011228037470078945}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('df025107-e499-44dc-a812-35453dd65de9','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749745789202_1s_1749745789189.png','','','','2025-06-12 16:29:54','2025-06-12 16:29:54','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"rgba(103, 17, 17, 1)\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.4447513812154695, \"position\": {\"x\": 0.7263535301910133, \"y\": 0.2720015942071618, \"z\": 0.6312096972701006}, \"rotation\": {\"x\": -0.40687518646563536, \"y\": 0.8130016337536071, \"z\": 0.30334130491619765}}, \"decals\": [], \"isDarkMode\": false, \"baseModelId\": \"0406ffff-add7-49c4-a7d4-dff1e83d00b4\", \"canvasBgColor\": 0, \"canvasBgOpacity\": \"0\"}}',5),('eda44251-7048-49c8-992a-70d0e8a8afb6','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750173553056_1s_1750173553024.png','','','','2025-06-17 15:19:20','2025-06-17 15:19:20','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.49171270718232046, \"position\": {\"x\": -0.04029047317848453, \"y\": 0.2307791992881418, \"z\": 0.950234865904228}, \"rotation\": {\"x\": -0.23825258373592045, \"y\": -0.04117951271369517, \"z\": -0.009997920603364728}}, \"decals\": [{\"id\": \"ece1fe25-d7fc-43e0-9050-14076063a3c8\", \"size\": {\"x\": 0.2, \"y\": 0.2, \"z\": 0.2}, \"isDraft\": true, \"position\": {\"x\": 0.021684106187945508, \"y\": 0.2543238881048708, \"z\": 0.17016562503614768}, \"rotation\": {\"x\": -0.44074370761703385, \"y\": -0.0029857112783816886, \"z\": -0.0014083252913819578}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}, {\"id\": \"9162c5f9-2f26-4151-8649-dfeac74fd0cf\", \"size\": {\"x\": 0.2, \"y\": 0.11310211946050096, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.020927764008631392, \"y\": 0.12159707743836606, \"z\": 0.19357195487035972}, \"rotation\": {\"x\": 0.16860609778205593, \"y\": 0.01258412852835166, \"z\": -0.002142038097889294}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('f51eecdd-13f4-417e-a662-2aa34779f7ec','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750478512208_1s_1750478512180.png','','','','2025-06-21 04:01:56','2025-06-21 04:01:56','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 1.5116959064327486, \"position\": {\"x\": -0.06605465302411331, \"y\": 0.22436201126463565, \"z\": 0.888096564469648}, \"rotation\": {\"x\": -0.24745472475754024, \"y\": -0.07198755052210173, \"z\": -0.01816868831395385}}, \"decals\": [{\"id\": \"e504494b-5905-4dd3-a106-424466f843c7\", \"size\": {\"x\": 0.2, \"y\": 0.17265624999999998, \"z\": 0.2}, \"isDraft\": false, \"position\": {\"x\": 0.00890836669719091, \"y\": 0.18985300847619435, \"z\": 0.21810730907758064}, \"rotation\": {\"x\": -0.08944970256564798, \"y\": -0.012519183717283324, \"z\": -0.0011228037470078945}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5),('fff3d3fd-de49-4e0b-9e70-b132426ddbd0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750172192188_1s_1750172192161.png','','','','2025-06-17 14:56:39','2025-06-17 14:56:39','{\"modelInfo\": {\"state\": {\"material\": {\"metalness\": 0, \"roughness\": 0.7, \"textureInfo\": null, \"textureRepeat\": 2}, \"canvasBackground\": {\"color\": \"#eee\", \"opacity\": 1}, \"currentOperatingBaseModelInfo\": null}, \"camera\": {\"far\": 1000, \"fov\": 75, \"near\": 0.1, \"aspect\": 0.9033149171270718, \"position\": {\"x\": -0.034651830139573125, \"y\": 0.34790210908531577, \"z\": 0.9130327714579184}, \"rotation\": {\"x\": -0.36405556653821497, \"y\": -0.03545020562107568, \"z\": -0.013504300234612203}}, \"decals\": [{\"id\": \"045398c9-6c59-4633-b447-9ac450478a23\", \"size\": {\"x\": 0.2, \"y\": 0.2, \"z\": 0.2}, \"position\": {\"x\": -0.029431335157246257, \"y\": 0.23984222249178777, \"z\": 0.20502723693203437}, \"rotation\": {\"x\": -0.3326927405458828, \"y\": -0.02078479538435301, \"z\": -0.007181261041177008}, \"metalness\": 0, \"roughness\": 0.9, \"modelValueSize\": 20, \"modelValueRotate\": null}], \"isDarkMode\": false, \"baseModelId\": \"a101126e-a6b6-4f62-a458-ac47fd363e36\"}}',5);
/*!40000 ALTER TABLE `custom_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `design_request`
--

DROP TABLE IF EXISTS `design_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `design_request` (
  `id` varchar(36) NOT NULL,
  `description` text,
  `userId` int(11) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(100) NOT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_4ba6d530242079590e99e5283b0` (`userId`),
  CONSTRAINT `FK_4ba6d530242079590e99e5283b0` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_request`
--

LOCK TABLES `design_request` WRITE;
/*!40000 ALTER TABLE `design_request` DISABLE KEYS */;
INSERT INTO `design_request` VALUES ('891a5c29-ad17-4c24-b0ff-2788e8eaccad','白色T恤，粉色图案haha1',NULL,'2025-06-15 13:35:26','2025-06-15 13:35:26','设计一个情侣衫','18742539196','265@qq.com');
/*!40000 ALTER TABLE `design_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `draft`
--

DROP TABLE IF EXISTS `draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draft` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `type` varchar(50) DEFAULT 'image',
  `uploaderId` int(11) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_a5fd75a51e6c58a65a8a16588f3` (`uploaderId`),
  CONSTRAINT `FK_a5fd75a51e6c58a65a8a16588f3` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draft`
--

LOCK TABLES `draft` WRITE;
/*!40000 ALTER TABLE `draft` DISABLE KEYS */;
INSERT INTO `draft` VALUES ('01cc6ad6-608d-4827-bfcf-eed73642e538','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265052343_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%B7%A6%E4%BE%A7.png','多角度图片_左侧','','image',5,NULL,'2025-06-18 16:44:15','2025-06-18 16:44:15'),('0b70b412-de11-4217-9f36-1a58d223d0da','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737948555_1s_1749737948530.png','模型截图','','image',5,NULL,'2025-06-12 14:19:10','2025-06-12 14:19:10'),('0c3dae6d-2c37-4663-aaba-4cf3e307ffec','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750169021798_1s_1750169021774.png','模型截图','','image',5,NULL,'2025-06-17 14:03:48','2025-06-17 14:03:48'),('1003d100-a037-4d40-9154-807f47be4613','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265241857_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-06-18 16:47:27','2025-06-18 16:47:26'),('135844be-e2ec-4f32-bc70-9d89c112f6cb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750491714283_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E8%83%8C%E9%9D%A2.png','多角度图片_背面','','image',5,NULL,'2025-06-21 07:41:58','2025-06-21 07:41:58'),('1f4d4ccb-e3b4-43fe-ad6f-91dba30c2df0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737904353_1s_1749737904324.png','模型截图','','image',5,NULL,'2025-06-12 14:18:26','2025-06-12 14:18:26'),('20f31fa2-504d-43b9-8b9d-246a0218a3c2','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265369416_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%B7%A6%E4%BE%A7.png','多角度图片_左侧','','image',5,NULL,'2025-06-18 16:49:35','2025-06-18 16:49:35'),('2bf26deb-4d87-4fef-8ec7-0f0bf1d3f11c','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749739121775_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749739121775.webm','模型录制视频','','image',5,NULL,'2025-06-12 14:38:46','2025-06-12 14:38:47'),('2e1c6de7-9e6e-42df-b8f9-8c44e096b887','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265369431_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%8F%B3%E4%BE%A7.png','多角度图片_右侧','','image',5,NULL,'2025-06-18 16:49:35','2025-06-18 16:49:35'),('49046caf-68db-45db-b1f8-043ed444b893','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265044146_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-06-18 16:44:09','2025-06-18 16:44:09'),('4a7357b7-107a-4fdf-9416-2367f47800c0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750491714363_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%8F%B3%E4%BE%A7.png','多角度图片_右侧','','image',5,NULL,'2025-06-21 07:41:58','2025-06-21 07:41:58'),('4b3bff39-e2d9-4cb7-81e6-125e8cbbc1ef','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737953852_1s_1749737953820.png','模型截图','','image',5,NULL,'2025-06-12 14:19:16','2025-06-12 14:19:16'),('4f256073-fbed-4de3-8c54-57495cee3e5d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749775116649_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749775116648.webm','模型录制视频','','image',5,NULL,'2025-06-13 00:38:45','2025-06-13 00:38:45'),('53333949-ef40-4629-9911-d3684b74fd0a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265165538_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-06-18 16:46:12','2025-06-18 16:46:11'),('53d7f6d6-311f-43bc-bd23-45ea941f23cb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750120199676_1s_1750120199669.png','模型截图','','image',5,NULL,'2025-06-17 00:30:04','2025-06-17 00:30:02'),('562ccdc7-23f3-40a5-ba9d-491b9dda661c','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750153999678_1s_1750153999608.png','模型截图','','image',5,NULL,'2025-06-17 09:53:19','2025-06-17 09:53:21'),('5a0bbde4-1c93-4d02-9b2e-22315d2d5b38','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265241928_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%B7%A6%E4%BE%A7.png','多角度图片_左侧','','image',5,NULL,'2025-06-18 16:47:28','2025-06-18 16:47:28'),('6b945dd1-cb22-4017-991f-d1b3eecd686c','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750414791813_1s_1750414791786.png','模型截图','','image',5,NULL,'2025-06-20 10:19:45','2025-06-20 10:19:52'),('70146d0e-0dec-4531-93db-8bdaaada9783','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737897833_1s_1749737897802.png','模型截图','','image',5,NULL,'2025-06-12 14:18:20','2025-06-12 14:18:20'),('718d34cf-ef2c-42c2-9da7-a397a0dab818','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749739092858_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749739092858.webm','模型录制视频','','image',5,NULL,'2025-06-12 14:38:25','2025-06-12 14:38:25'),('7429b5c5-0297-45e6-9877-27d4f98307d9','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750255027822_1s_1750255027790.png','模型截图','','image',5,NULL,'2025-06-18 13:57:13','2025-06-18 13:57:13'),('74a04d97-5a75-4552-98fb-c6d6611fbf41','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750292150745_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%B7%A6%E4%BE%A7.png','多角度图片_左侧','','image',5,NULL,'2025-06-19 00:15:55','2025-06-19 00:15:55'),('790da09f-4295-445a-b9a9-3ef663969e74','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737906544_1s_1749737906529.png','模型截图','','image',5,NULL,'2025-06-12 14:18:28','2025-06-12 14:18:28'),('84f51a59-9944-4ff2-b4ca-9fbc1a9daac0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737908741_1s_1749737908725.png','模型截图','','image',5,NULL,'2025-06-12 14:18:31','2025-06-12 14:18:31'),('8a81c696-b9b5-4e8a-93ae-1696d15bf064','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750414658971_1s_1750414658939.png','模型截图','','image',5,NULL,'2025-06-20 10:17:32','2025-06-20 10:17:40'),('8a9ea595-352f-4025-a3b8-77055791832f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265241944_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%8F%B3%E4%BE%A7.png','多角度图片_右侧','','image',5,NULL,'2025-06-18 16:47:29','2025-06-18 16:47:28'),('8eaeeca9-6c60-40f0-947d-6b4564d09c7a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265174255_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%B7%A6%E4%BE%A7.png','多角度图片_左侧','','image',5,NULL,'2025-06-18 16:46:16','2025-06-18 16:46:16'),('905f3bb8-ff15-4752-ba6e-e3b4e986588b','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749737126315_1s_1749737126271.png','模型截图','','image',5,NULL,'2025-06-12 14:05:31','2025-06-12 14:05:31'),('978c91ec-154e-4aff-9672-33d44570b2f4','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750467909546_1s_1750467909516.png','模型截图','','image',5,NULL,'2025-06-21 01:05:15','2025-06-21 01:05:15'),('998b5229-fd83-42ba-ba59-511d1ab85f57','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750172514202_1s_1750172514200.png','贴纸草稿','','composition',5,'{\"data\": {\"unit\": \"px\", \"children\": [{\"id\": \"this_is_canvas_id\", \"type\": \"canvas\", \"width\": {\"unit\": \"px\", \"value\": 500}, \"filter\": {\"filterUrl\": {\"filterId\": \"\", \"filterChildren\": [], \"isCompositeFilter\": false}, \"filterBlur\": {\"unit\": \"px\", \"value\": 0}, \"filterSepia\": 0, \"filterInvert\": 0, \"filterOpacity\": 100, \"filterContrast\": 100, \"filterSaturate\": 100, \"filterGrayscale\": 0, \"filterHueRotate\": 0, \"filterBrightness\": 100}, \"height\": {\"unit\": \"px\", \"value\": 500}, \"clipPath\": null, \"undeletable\": true, \"backgroundColor\": {\"color\": \"rgba(0,0,0,0)\"}, \"targetComputedWidth\": 500, \"targetComputedHeight\": 500}, {\"id\": \"_1750172170383\", \"type\": \"text\", \"filter\": {\"filterUrl\": {\"filterId\": \"\", \"filterChildren\": [], \"isCompositeFilter\": false}, \"filterBlur\": {\"unit\": \"px\", \"value\": 0}, \"filterSepia\": 0, \"filterInvert\": 0, \"filterOpacity\": 100, \"filterContrast\": 100, \"filterSaturate\": 100, \"filterGrayscale\": 0, \"filterHueRotate\": 0, \"filterBrightness\": 100}, \"zIndex\": 0, \"fontSize\": {\"unit\": \"px\", \"value\": 24}, \"position\": {\"top\": {\"unit\": \"px\", \"value\": 0}, \"left\": {\"unit\": \"px\", \"value\": 0}, \"right\": {\"unit\": \"px\", \"value\": 0}, \"bottom\": {\"unit\": \"px\", \"value\": 0}, \"center\": true, \"verticalCenter\": true, \"horizontalCenter\": true}, \"fontColor\": {\"type\": \"pure\", \"color\": \"#000\"}, \"imageInfo\": null, \"transform\": {\"skewX\": 0, \"skewY\": 0, \"scaleX\": 1, \"scaleY\": 1, \"scaleZ\": 1, \"rotateX\": 0, \"rotateY\": 0, \"rotateZ\": 0, \"translateX\": {\"unit\": \"px\", \"value\": 0}, \"translateY\": {\"unit\": \"px\", \"value\": 0}, \"translateZ\": {\"unit\": \"px\", \"value\": 0}, \"perspective\": {\"unit\": \"px\", \"value\": 0}}, \"fontWeight\": \"500\", \"lineHeight\": 1, \"textShadow\": [], \"containerEl\": null, \"isRoundText\": false, \"textContent\": \"小李每天要开心！！！！\", \"writingMode\": \"htb\", \"letterSpacing\": 0, \"isReverseLetter\": false, \"textStrokeColor\": {\"type\": \"pure\", \"color\": \"#fff\"}, \"textStrokeWidth\": {\"unit\": \"px\", \"value\": 0}, \"roundTextStartDeg\": 0, \"isCounterclockwise\": false, \"isPointingToCenter\": true, \"targetComputedWidth\": 264, \"isTraditionalChinese\": false, \"targetComputedHeight\": 24, \"isMultipleLineOutExpand\": false, \"roundTextVerticalRadius\": {\"unit\": \"px\", \"value\": 100}, \"roundTextHorizontalRadius\": {\"unit\": \"px\", \"value\": 100}}], \"svgFilter\": {\"children\": []}, \"showCanvasRealSize\": false, \"supportBackgroundColor\": {\"type\": \"pure\", \"color\": \"rgba(0,0,0,0)\"}}}','2025-06-17 15:01:56','2025-06-17 15:01:56'),('99ff169a-d3fe-4678-aa27-3ce5161e1319','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256301042_1s_1750256301010.png','模型截图','','image',5,NULL,'2025-06-18 14:18:27','2025-06-18 14:18:27'),('9cbf357d-4e69-4308-b898-f3fd78f7bcf9','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750491714323_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%B7%A6%E4%BE%A7.png','多角度图片_左侧','','image',5,NULL,'2025-06-21 07:41:58','2025-06-21 07:41:58'),('9d4e43fb-1f16-4ee7-b3d7-e9b1f56fa504','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750292150765_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%8F%B3%E4%BE%A7.png','多角度图片_右侧','','image',5,NULL,'2025-06-19 00:15:58','2025-06-19 00:15:58'),('9d98595b-1bc8-4b03-9849-d09889a86344','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265049822_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E8%83%8C%E9%9D%A2.png','多角度图片_背面','','image',5,NULL,'2025-06-18 16:44:12','2025-06-18 16:44:11'),('ae1bc0b8-0233-419e-b520-73a636a684ba','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750491714226_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-06-21 07:41:58','2025-06-21 07:41:58'),('b5afd87c-1934-477e-9368-0dfa8dd23733','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265055186_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%8F%B3%E4%BE%A7.png','多角度图片_右侧','','image',5,NULL,'2025-06-18 16:44:17','2025-06-18 16:44:17'),('bc1e1e86-97a8-4691-be5d-98f21b8af412','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265369377_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E8%83%8C%E9%9D%A2.png','多角度图片_背面','','image',5,NULL,'2025-06-18 16:49:33','2025-06-18 16:49:33'),('be3217cc-7da9-4f10-a9ea-374b2552071c','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750475244991_1s_1750475244953.png','模型截图','','image',5,NULL,'2025-06-21 03:08:16','2025-06-21 03:08:17'),('c02c4022-f40d-4c26-8d65-c332ca5341e0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750475278791_1s_1750475278772.png','模型截图','','image',5,NULL,'2025-06-21 03:08:14','2025-06-21 03:08:14'),('c1db9915-56e9-49f0-b246-54d31065452a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265241888_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E8%83%8C%E9%9D%A2.png','多角度图片_背面','','image',5,NULL,'2025-06-18 16:47:26','2025-06-18 16:47:26'),('c494bd43-48d7-4917-b908-dbffa553fbc5','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265176363_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E5%8F%B3%E4%BE%A7.png','多角度图片_右侧','','image',5,NULL,'2025-06-18 16:46:18','2025-06-18 16:46:18'),('c8560d0d-26ca-4bab-b961-6f498690e416','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265172046_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E8%83%8C%E9%9D%A2.png','多角度图片_背面','','image',5,NULL,'2025-06-18 16:46:14','2025-06-18 16:46:14'),('dac5e282-83c9-4844-9a1a-eb4abaf63878','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749775175138_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749775175138.webm','模型录制视频','','image',5,NULL,'2025-06-13 00:39:45','2025-06-13 00:39:44'),('daed7bc5-2133-45fb-8766-e7a88f60ea74','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750465830281_1s_1750465830248.png','模型截图','','image',5,NULL,'2025-06-21 00:30:31','2025-06-21 00:30:32'),('dca41761-f740-48e3-8a43-cacc2986e05f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750292150701_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-06-19 00:15:56','2025-06-19 00:15:56'),('e4642ee4-b378-41f9-a8c2-16431ee3a2ef','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750170334586_1s_1750170334525.png','模型截图','','image',5,NULL,'2025-06-17 14:25:44','2025-06-17 14:25:44'),('ece1fe25-d7fc-43e0-9050-14076063a3c8','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750173557860_1s_1750173557857.png','贴纸草稿','','composition',5,'{\"data\": {\"unit\": \"px\", \"children\": [{\"id\": \"this_is_canvas_id\", \"type\": \"canvas\", \"width\": {\"unit\": \"px\", \"value\": 500}, \"filter\": {\"filterUrl\": {\"filterId\": \"\", \"filterChildren\": [], \"isCompositeFilter\": false}, \"filterBlur\": {\"unit\": \"px\", \"value\": 0}, \"filterSepia\": 0, \"filterInvert\": 0, \"filterOpacity\": 100, \"filterContrast\": 100, \"filterSaturate\": 100, \"filterGrayscale\": 0, \"filterHueRotate\": 0, \"filterBrightness\": 100}, \"height\": {\"unit\": \"px\", \"value\": 500}, \"clipPath\": null, \"undeletable\": true, \"backgroundColor\": {\"color\": \"rgba(0,0,0,0)\"}, \"targetComputedWidth\": 500, \"targetComputedHeight\": 500}, {\"id\": \"_1750172170383\", \"type\": \"text\", \"filter\": {\"filterUrl\": {\"filterId\": \"\", \"filterChildren\": [], \"isCompositeFilter\": false}, \"filterBlur\": {\"unit\": \"px\", \"value\": 0}, \"filterSepia\": 0, \"filterInvert\": 0, \"filterOpacity\": 100, \"filterContrast\": 100, \"filterSaturate\": 100, \"filterGrayscale\": 0, \"filterHueRotate\": 0, \"filterBrightness\": 100}, \"zIndex\": 0, \"fontSize\": {\"unit\": \"px\", \"value\": 24}, \"position\": {\"top\": {\"unit\": \"px\", \"value\": 0}, \"left\": {\"unit\": \"px\", \"value\": 0}, \"right\": {\"unit\": \"px\", \"value\": 0}, \"bottom\": {\"unit\": \"px\", \"value\": 0}, \"center\": true, \"verticalCenter\": true, \"horizontalCenter\": true}, \"fontColor\": {\"type\": \"pure\", \"color\": \"#000\"}, \"imageInfo\": null, \"transform\": {\"skewX\": 0, \"skewY\": 0, \"scaleX\": 1, \"scaleY\": 1, \"scaleZ\": 1, \"rotateX\": 0, \"rotateY\": 0, \"rotateZ\": 0, \"translateX\": {\"unit\": \"px\", \"value\": 0}, \"translateY\": {\"unit\": \"px\", \"value\": 0}, \"translateZ\": {\"unit\": \"px\", \"value\": 0}, \"perspective\": {\"unit\": \"px\", \"value\": 0}}, \"fontWeight\": \"500\", \"lineHeight\": 1, \"textShadow\": [], \"containerEl\": null, \"isRoundText\": false, \"textContent\": \"小李每天要开心！！！！\", \"writingMode\": \"htb\", \"letterSpacing\": 0, \"isReverseLetter\": false, \"textStrokeColor\": {\"type\": \"pure\", \"color\": \"#fff\"}, \"textStrokeWidth\": {\"unit\": \"px\", \"value\": 0}, \"roundTextStartDeg\": 0, \"isCounterclockwise\": false, \"isPointingToCenter\": true, \"targetComputedWidth\": 264, \"isTraditionalChinese\": false, \"targetComputedHeight\": 24, \"isMultipleLineOutExpand\": false, \"roundTextVerticalRadius\": {\"unit\": \"px\", \"value\": 100}, \"roundTextHorizontalRadius\": {\"unit\": \"px\", \"value\": 100}}], \"svgFilter\": {\"children\": []}, \"showCanvasRealSize\": false, \"supportBackgroundColor\": {\"type\": \"pure\", \"color\": \"rgba(0,0,0,0)\"}}}','2025-06-17 15:19:19','2025-06-17 15:19:19'),('edd386e5-a808-4bdf-b018-fd6bc334ed4b','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749775178837_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749775178837.webm','模型录制视频','','image',5,NULL,'2025-06-13 00:39:46','2025-06-13 00:39:46'),('ee9d181a-9bd8-4c18-92ee-cdff7b217bff','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750475264287_1s_1750475264259.png','模型截图','','image',5,NULL,'2025-06-21 03:08:13','2025-06-21 03:08:13'),('f01bffef-653b-4e7b-af74-372c5cdbc77f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749739529166_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749739529166.webm','模型录制视频','','image',5,NULL,'2025-06-12 14:45:34','2025-06-12 14:45:34'),('fdcd96a0-caac-4309-860d-ac6849091854','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749740277744_1s_%E5%BD%95%E5%88%B6%E8%A7%86%E9%A2%91_1749740277743.webm','模型录制视频','','image',5,NULL,'2025-06-12 14:58:03','2025-06-12 14:58:03'),('ff406d9a-116a-4964-9f88-3d6854cc4ac7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750265369331_1s_%E5%A4%9A%E8%A7%92%E5%BA%A6%E5%9B%BE%E7%89%87_%E6%AD%A3%E9%9D%A2.png','多角度图片_正面','','image',5,NULL,'2025-06-18 16:49:35','2025-06-18 16:49:34');
/*!40000 ALTER TABLE `draft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` varchar(36) NOT NULL,
  `url` varchar(200) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `size` varchar(100) DEFAULT '',
  `rawName` varchar(100) DEFAULT '',
  `type` varchar(100) DEFAULT '',
  `thumbnail` varchar(255) DEFAULT '',
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `uploaderId` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT '',
  `keywords` varchar(100) DEFAULT '',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_e529b53c18487a72385a6a440f0` (`uploaderId`),
  CONSTRAINT `FK_e529b53c18487a72385a6a440f0` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `font_template`
--

DROP TABLE IF EXISTS `font_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `font_template` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `key` varchar(1000) DEFAULT '',
  `thumbnail` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `category` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `keywords` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `FK_3060138a40ac893aa984c082390` (`uploaderId`),
  CONSTRAINT `FK_3060138a40ac893aa984c082390` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `font_template`
--

LOCK TABLES `font_template` WRITE;
/*!40000 ALTER TABLE `font_template` DISABLE KEYS */;
INSERT INTO `font_template` VALUES ('304e1f30-51d3-4f0a-848e-6537d4235907','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749114110062_1s_Heart%20Breaking%20Bad.otf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749114109860_1s_1749114109857.png','绝命毒师字体','','',5,0,'{}','2025-06-05 09:01:49','2025-06-20 02:34:05',''),('60cc1615-f567-40d0-845c-a4cd55c6b50f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748862915884_1s_ChillRoundM.otf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748862913749_1s_1748862913722.png','ChillRoundM.otf','','',5,0,'{}','2025-06-02 11:15:25','2025-06-02 11:15:25',''),('643198bb-f1a2-47ef-8b76-2498bd270915','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750677127463_1s_cole.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750677126803_1s_1750677126801.png','可口可乐字体','','',5,0,'{}','2025-06-23 11:11:54','2025-06-23 11:11:54',''),('68511302-251a-46ed-a6c8-0b18fcc6dfc7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750371495388_1s_YeZiGongChangTangYingHei-2.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750371492084_1s_1750371492082.png','YeZiGongChangTangYingHei-2.ttf','','',5,0,'{}','2025-06-19 22:18:54','2025-06-19 22:18:54',''),('76f13f06-a0fd-48e2-904d-02d3d9e698f1','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750386527170_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750386526556_1s_1750386526537.png','ZCOOLKuaiLe-Regular.ttf','','字体描述',5,0,'{}','2025-06-20 02:28:47','2025-06-20 02:36:04','通用,日文'),('bf4dd2d7-eaf0-4e8f-aadb-60cb41af4584','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326084125_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326084020_1s_1750326084017.png','ZCOOLKuaiLe-Regular.ttf','','',5,0,'{}','2025-06-19 09:41:20','2025-06-19 09:41:20',''),('da49f532-b2a6-467f-bba4-61b2f454cd26','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326056038_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326055887_1s_1750326055885.png','ZCOOLKuaiLe-Regular.ttf','','',5,0,'{}','2025-06-19 09:40:53','2025-06-19 09:40:53',''),('e324761a-b89a-45fe-b02c-ae5ee9880732','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326031579_1s_ZCOOLKuaiLe-Regular.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750326031254_1s_1750326031251.png','ZCOOLKuaiLe-Regular.ttf','','',5,0,'{}','2025-06-19 09:40:29','2025-06-19 09:40:29',''),('ea6009e9-1c28-4436-9538-bd8abb53f78d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750372032553_1s_YeZiGongChangTangYingHei-2.ttf','','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750372030437_1s_1750372030434.png','YeZiGongChangTangYingHei-2.ttf','','',5,0,'{}','2025-06-19 22:27:45','2025-06-19 22:27:45','');
/*!40000 ALTER TABLE `font_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(1000) DEFAULT '',
  `type` varchar(1000) DEFAULT '',
  `price` decimal(10,2) NOT NULL,
  `salePrice` decimal(10,2) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT '0',
  `specifications` varchar(1000) DEFAULT '',
  `tags` varchar(1000) DEFAULT '',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isLimitedEdition` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否绝版：0-否，1-是',
  `images` json DEFAULT NULL,
  `code` varchar(50) NOT NULL DEFAULT '',
  `isPublish` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发布：false-未发布，true-已发布',
  `keywords` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('04e38e67-98b5-4171-9b87-cd8050f34b2c','vue T恤 ','vue 介绍','',0.00,0.00,0,'','',1,NULL,'2025-06-21 10:48:37','2025-06-21 12:22:59',0,'[\"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750502915144_1s_4e39c9f5-cb8d-4590-93f8-68bd02701806\"]','',1,'程序员,白色'),('cad74985-c6ec-4afe-8b9a-bae0f0b8ea2b','kongshangpin','','',0.00,0.00,0,'','',1,NULL,'2025-06-21 11:27:51','2025-06-21 11:32:19',0,'[]','',1,''),('edcb80de-eb41-44f2-90ff-a899d840e84b','纯白色T恤','','',0.00,0.00,0,'','',1,NULL,'2025-06-18 14:20:26','2025-06-20 00:31:54',0,'[\"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412888_1s_b0ca56c1-b693-4396-8f5d-9b85560d935e\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412895_1s_87c29ed6-43ba-4ec3-866a-284ddeaf4d01\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412897_1s_40c346c5-ad0c-4235-9237-edcb8c74a3b8\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412899_1s_f21d4dba-c8d2-4460-8fd6-32ffa187b44f\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412899_1s_a529f658-d069-47a6-bb30-cf458b69010d\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412899_1s_0b3044de-718b-4b77-9e1d-51678b461410\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412900_1s_3aeebf9e-1f84-4095-9b21-f968e4235b53\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750256412900_1s_0c07f952-e263-4d18-9112-4f839014913f\"]','',1,''),('f426c781-a212-4ffa-ba41-9c0e05a1ecce','白色polo','','',0.00,0.00,0,'','',1,NULL,'2025-06-18 14:55:10','2025-06-20 00:18:20',0,'[\"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501322_1s_603a32a3-6f04-45b9-b622-8da0f037303b\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501329_1s_9ca8d001-70e8-4d24-8e3c-0006e53ae5a5\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501332_1s_0d8fee28-fcd1-4716-a895-97cf01bc80cd\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501333_1s_e6f7925f-f42b-4c46-ae09-f3d1b26a172c\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501333_1s_253ac64a-e23f-42eb-aa50-652cbc1bf766\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501333_1s_cf13aca1-2e7a-4d00-9a9c-20fd7f166586\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501333_1s_a166131d-3e52-4883-9b5e-a4257e8c9b64\", \"https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750258501333_1s_6f7e8106-1247-48f5-a6de-cf574759608d\"]','',1,'');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_model`
--

DROP TABLE IF EXISTS `product_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_model` (
  `id` varchar(36) NOT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `price` varchar(1000) DEFAULT NULL,
  `url` varchar(1000) DEFAULT NULL,
  `keywords` varchar(1000) DEFAULT '',
  `ref_count` int(11) DEFAULT '0',
  `like_count` int(11) DEFAULT '0',
  `save_count` int(11) DEFAULT '0',
  `link_count` int(11) DEFAULT '0',
  `thumbnail` varchar(1000) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_model`
--

LOCK TABLES `product_model` WRITE;
/*!40000 ALTER TABLE `product_model` DISABLE KEYS */;
INSERT INTO `product_model` VALUES ('0406ffff-add7-49c4-a7d4-dff1e83d00b4','tshirt.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748865053369_1s_tshirt.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748865051768_1s_1748865051763.png',NULL,'2025-06-02 11:51:28','2025-06-02 11:51:28'),('085d6c49-d882-4af0-a02a-d0c109109fd0','mug.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112910107_1s_mug.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112909539_1s_1749112909538.png',NULL,'2025-06-05 08:41:51','2025-06-05 08:41:51'),('0872a0a2-8287-41e4-9359-631f12d5f0b6','t-shirt_-_lengan_panjang.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110901040_1s_t-shirt_-_lengan_panjang.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110900613_1s_1749110900611.png',NULL,'2025-06-05 08:08:25','2025-06-05 08:08:25'),('201585fd-6a42-477c-ad10-0fb6645f818c','tshirt_model.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110277587_1s_tshirt_model.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110277270_1s_1749110277268.png',NULL,'2025-06-05 07:57:57','2025-06-05 07:57:57'),('2de7c2db-0bb6-4be7-8945-a1bb44107dea','tshirt (4).glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110632843_1s_tshirt%20%284%29.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110631279_1s_1749110631276.png',NULL,'2025-06-05 08:03:52','2025-06-05 08:03:52'),('3d8269e9-8019-47f0-b933-7fc50a1a2a68','white_baseball_cap.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112006658_1s_white_baseball_cap.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112006141_1s_1749112006139.png',NULL,'2025-06-05 08:26:47','2025-06-05 08:26:47'),('4c41551e-e476-464c-985c-6848610bfc80','tshirt (2).glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110306767_1s_tshirt%20%282%29.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110306624_1s_1749110306621.png',NULL,'2025-06-05 07:58:28','2025-06-05 07:58:28'),('635f1851-dad3-4b52-ac8d-ed379b4e5a2a','plain_cup.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112581064_1s_plain_cup.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112580842_1s_1749112580840.png',NULL,'2025-06-05 08:36:20','2025-06-05 08:36:20'),('668b4da6-453d-4613-a1f9-88aca43518a7','tshirt_with_etecet.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110776396_1s_tshirt_with_etecet.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110775972_1s_1749110775969.png',NULL,'2025-06-05 08:06:18','2025-06-05 08:06:18'),('6e803cf1-8677-42a5-aa1d-6ff3733bc0e6','tshirt.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749106430191_1s_tshirt.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749106429405_1s_1749106429397.png',NULL,'2025-06-05 06:53:51','2025-06-05 06:53:51'),('8e8b2abf-2754-426a-924f-c9a709711053','mouse_pad.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112319005_1s_mouse_pad.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112318156_1s_1749112318156.png',NULL,'2025-06-05 08:31:58','2025-06-05 08:31:58'),('8fc642be-525f-43c5-b106-d2abb9ba3fe3','tshirt_with_etecet.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110632896_1s_tshirt_with_etecet.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110631291_1s_1749110631289.png',NULL,'2025-06-05 08:03:55','2025-06-05 08:03:55'),('96237295-8801-4d57-bce3-cd178fe62881','cup.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112532881_1s_cup.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749112532243_1s_1749112532242.png',NULL,'2025-06-05 08:35:32','2025-06-05 08:35:32'),('9d0b7444-da1f-4996-8d6c-56da3e653793','t-shirt_polo_lengan_pendek.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110945870_1s_t-shirt_polo_lengan_pendek.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110945719_1s_1749110945715.png',NULL,'2025-06-05 08:09:10','2025-06-05 08:09:10'),('a101126e-a6b6-4f62-a458-ac47fd363e36','tshirt (3).glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110337967_1s_tshirt%20%283%29.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110337846_1s_1749110337844.png',NULL,'2025-06-05 07:59:04','2025-06-05 07:59:04'),('b02c682b-393a-451d-991d-71f705a0bd1c','japanese_hat_jingasa.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749111376404_1s_japanese_hat_jingasa.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749111375925_1s_1749111375924.png',NULL,'2025-06-05 08:16:20','2025-06-05 08:16:20'),('cc0b92af-b04a-4ecf-a1b8-67745be6a7c9','tshirt (4).glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110371901_1s_tshirt%20%284%29.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110371779_1s_1749110371776.png',NULL,'2025-06-05 07:59:31','2025-06-05 07:59:31'),('f6acae3e-3059-42e2-8b14-c7aac16c9f0e','low_poly_stylized_hat.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749111659784_1s_low_poly_stylized_hat.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749111659033_1s_1749111659032.png',NULL,'2025-06-05 08:21:15','2025-06-05 08:21:15'),('f8a17d77-d5ca-4052-9621-47a1f1706019','tshirt (1).glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749109210933_1s_tshirt%20%281%29.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749109210264_1s_1749109210262.png',NULL,'2025-06-05 07:40:24','2025-06-05 07:40:24'),('ff05c413-f430-4f1b-9c47-d4b6699b12e5','tshirt_mockup_brock_creative_final.glb',NULL,NULL,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110840145_1s_tshirt_mockup_brock_creative_final.glb','',0,0,0,0,'https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749110839739_1s_1749110839734.png',NULL,'2025-06-05 08:07:29','2025-06-05 08:07:29');
/*!40000 ALTER TABLE `product_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psd_template`
--

DROP TABLE IF EXISTS `psd_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psd_template` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `key` varchar(1000) DEFAULT '',
  `thumbnail` json DEFAULT NULL,
  `name` varchar(1000) DEFAULT '',
  `category` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_fa6f703fc301e39ef3215c8710c` (`uploaderId`),
  CONSTRAINT `FK_fa6f703fc301e39ef3215c8710c` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psd_template`
--

LOCK TABLES `psd_template` WRITE;
/*!40000 ALTER TABLE `psd_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `psd_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relation`
--

DROP TABLE IF EXISTS `relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `followerId` int(11) NOT NULL,
  `followedId` int(11) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relation`
--

LOCK TABLES `relation` WRITE;
/*!40000 ALTER TABLE `relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sentences`
--

DROP TABLE IF EXISTS `sentences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sentences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sentences`
--

LOCK TABLES `sentences` WRITE;
/*!40000 ALTER TABLE `sentences` DISABLE KEYS */;
INSERT INTO `sentences` VALUES (2,'快乐','2025-06-26 10:30:49.935399','2025-06-26 10:30:49.935399',NULL),(3,'内容','2025-06-26 10:45:43.282480','2025-06-26 10:45:43.282480','描述'),(4,'1','2025-06-26 10:48:57.659276','2025-06-26 10:48:57.659276',''),(5,'2','2025-06-26 10:49:00.150821','2025-06-26 10:49:00.150821',''),(6,'3','2025-06-26 10:49:02.867894','2025-06-26 10:49:02.867894','');
/*!40000 ALTER TABLE `sentences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sticker`
--

DROP TABLE IF EXISTS `sticker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sticker` (
  `id` varchar(36) NOT NULL,
  `url` varchar(1000) DEFAULT '',
  `keywords` varchar(1000) DEFAULT '',
  `name` varchar(1000) DEFAULT '',
  `group` varchar(1000) DEFAULT '',
  `description` varchar(1000) DEFAULT '',
  `uploaderId` int(11) DEFAULT NULL,
  `isPublic` tinyint(4) NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `key` varchar(1000) DEFAULT '',
  `isTexture` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_63f76d2f8fb3b56b4b10264d398` (`uploaderId`),
  CONSTRAINT `FK_63f76d2f8fb3b56b4b10264d398` FOREIGN KEY (`uploaderId`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sticker`
--

LOCK TABLES `sticker` WRITE;
/*!40000 ALTER TABLE `sticker` DISABLE KEYS */;
INSERT INTO `sticker` VALUES ('025b127c-041d-4601-81d8-b0bb4de1a95e','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_02f50dfb-b19b-4454-8417-379443044d02','','Image_fx (3).png','','',NULL,0,NULL,'2025-06-03 10:08:42','2025-06-03 10:08:42','',0),('03cb5a25-0a18-487d-84e8-4135f17b20fe','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_bcddadb1-f8cf-4053-a966-a25be997298d','','74.jpg','','',NULL,0,NULL,'2025-06-03 10:08:54','2025-06-03 10:08:54','',0),('045398c9-6c59-4633-b447-9ac450478a23','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750172197280_1s_1750172197276.png','','','','',5,0,'{\"data\": {\"unit\": \"px\", \"children\": [{\"id\": \"this_is_canvas_id\", \"type\": \"canvas\", \"width\": {\"unit\": \"px\", \"value\": 500}, \"filter\": {\"filterUrl\": {\"filterId\": \"\", \"filterChildren\": [], \"isCompositeFilter\": false}, \"filterBlur\": {\"unit\": \"px\", \"value\": 0}, \"filterSepia\": 0, \"filterInvert\": 0, \"filterOpacity\": 100, \"filterContrast\": 100, \"filterSaturate\": 100, \"filterGrayscale\": 0, \"filterHueRotate\": 0, \"filterBrightness\": 100}, \"height\": {\"unit\": \"px\", \"value\": 500}, \"clipPath\": null, \"undeletable\": true, \"backgroundColor\": {\"color\": \"rgba(0,0,0,0)\"}, \"targetComputedWidth\": 500, \"targetComputedHeight\": 500}, {\"id\": \"_1750172170383\", \"type\": \"text\", \"filter\": {\"filterUrl\": {\"filterId\": \"\", \"filterChildren\": [], \"isCompositeFilter\": false}, \"filterBlur\": {\"unit\": \"px\", \"value\": 0}, \"filterSepia\": 0, \"filterInvert\": 0, \"filterOpacity\": 100, \"filterContrast\": 100, \"filterSaturate\": 100, \"filterGrayscale\": 0, \"filterHueRotate\": 0, \"filterBrightness\": 100}, \"zIndex\": 0, \"fontSize\": {\"unit\": \"px\", \"value\": 24}, \"position\": {\"top\": {\"unit\": \"px\", \"value\": 0}, \"left\": {\"unit\": \"px\", \"value\": 0}, \"right\": {\"unit\": \"px\", \"value\": 0}, \"bottom\": {\"unit\": \"px\", \"value\": 0}, \"center\": true, \"verticalCenter\": true, \"horizontalCenter\": true}, \"fontColor\": {\"type\": \"pure\", \"color\": \"#000\"}, \"imageInfo\": null, \"transform\": {\"skewX\": 0, \"skewY\": 0, \"scaleX\": 1, \"scaleY\": 1, \"scaleZ\": 1, \"rotateX\": 0, \"rotateY\": 0, \"rotateZ\": 0, \"translateX\": {\"unit\": \"px\", \"value\": 0}, \"translateY\": {\"unit\": \"px\", \"value\": 0}, \"translateZ\": {\"unit\": \"px\", \"value\": 0}, \"perspective\": {\"unit\": \"px\", \"value\": 0}}, \"fontWeight\": \"500\", \"lineHeight\": 1, \"textShadow\": [], \"containerEl\": null, \"isRoundText\": false, \"textContent\": \"小李每天要开心！\", \"writingMode\": \"htb\", \"letterSpacing\": 0, \"isReverseLetter\": false, \"textStrokeColor\": {\"type\": \"pure\", \"color\": \"#fff\"}, \"textStrokeWidth\": {\"unit\": \"px\", \"value\": 0}, \"roundTextStartDeg\": 0, \"isCounterclockwise\": false, \"isPointingToCenter\": true, \"targetComputedWidth\": 192, \"isTraditionalChinese\": false, \"targetComputedHeight\": 24, \"isMultipleLineOutExpand\": false, \"roundTextVerticalRadius\": {\"unit\": \"px\", \"value\": 100}, \"roundTextHorizontalRadius\": {\"unit\": \"px\", \"value\": 100}}], \"svgFilter\": {\"children\": []}, \"showCanvasRealSize\": false, \"supportBackgroundColor\": {\"type\": \"pure\", \"color\": \"rgba(0,0,0,0)\"}}}','2025-06-17 14:56:38','2025-06-17 14:56:38','',0),('0c74c167-648c-415f-9079-5bff65b39d07','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_3de62ae4-b199-4144-814a-a0bd9bef6ac5','','截图20250602155840.png','','',NULL,0,NULL,'2025-06-03 10:08:34','2025-06-03 10:08:34','',0),('0df619e3-e2c9-4571-9649-aa045aaf5512','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_8811a28e-b531-453a-b94c-fd2c5804c254','','Image_fx (1).png','','',NULL,0,NULL,'2025-06-03 10:08:41','2025-06-03 10:08:41','',0),('0e53793a-6412-4116-a852-7e05d0dec407','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_f9e9ba9d-a353-484d-9491-f57f370fefa3','','27.jpg','','',NULL,0,NULL,'2025-06-03 10:09:00','2025-06-03 10:09:00','',0),('0f4522b9-9489-4f31-8fd4-976598b85523','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_093cbf88-d076-4bdc-9f89-bc25166cc180','','Image_fx (7).png','','',NULL,0,NULL,'2025-06-03 10:08:29','2025-06-03 10:08:29','',0),('17fd9220-4f26-4168-8380-8c28b6e6d283','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_95cb1dd0-0891-4524-9689-99535809c6c9','','截图20250602155854.png','','',NULL,0,NULL,'2025-06-03 10:08:35','2025-06-03 10:08:35','',0),('19045856-558b-406a-9e8e-b7ed7b8b5d2a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748861791729_1s_%E7%81%AB.svg','','','','',5,0,NULL,'2025-06-02 10:56:35','2025-06-02 10:56:35','',0),('1b184367-bf6a-4109-8547-a455a73bed0f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_42df0b7e-9c95-4d9c-8396-1d23174ea12b','','59.jpg','','',NULL,0,NULL,'2025-06-03 10:08:50','2025-06-03 10:08:50','',0),('1cd1566d-ac82-4473-b531-76f76fe95dc4','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_69ae0e0e-2646-4703-a8bd-e905ed8e8218','','122.jpg','','',NULL,0,NULL,'2025-06-03 10:09:02','2025-06-03 10:09:02','',0),('1d89fad3-f587-4544-92c8-7462de8898e5','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_0d513eee-3d87-4aff-b668-93c504e6344b','','截图20250602151032.png','','',NULL,0,NULL,'2025-06-03 10:08:31','2025-06-03 10:08:31','',0),('1ef99139-bb34-44ee-b82c-c13a27b951bb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_76f2a5b2-8879-4cb0-9ca2-cb567c3602d2','','80.jpg','','',NULL,0,NULL,'2025-06-03 10:08:53','2025-06-03 10:08:53','',0),('224c6111-c6a5-413b-abfd-dbcdc8439a4d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441329_1s_Image_fx%20%287%29.png','','','','',5,0,NULL,'2025-06-04 03:24:08','2025-06-04 03:24:08','',0),('2278c8cd-86b0-4220-9ab6-469834d64036','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749289914809_1s_white-fabric-texture-background.jpg','','','','',5,0,NULL,'2025-06-07 09:52:03','2025-06-07 09:52:03','',0),('2359c968-1d13-4e37-aa97-ba4689dc63eb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_b0131a3d-37e5-4813-adb3-6a92e62d91d8','','截图20250602154123.png','','',NULL,0,NULL,'2025-06-03 10:08:44','2025-06-03 10:08:44','',0),('26bab126-caa9-4c1d-a490-a5c65a13e99d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_1b86caa9-bee8-46f0-8082-fbb2e8ba5a1d','','截图20250603152056.png','','',NULL,0,NULL,'2025-06-03 10:08:36','2025-06-03 10:08:36','',0),('27c5ebd0-8542-49c9-8d9b-13d5a628dd22','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_36a70e3b-231d-4b3f-9575-ee0918af01cb','','13.jpg','','',NULL,0,NULL,'2025-06-03 10:08:56','2025-06-03 10:08:56','',0),('28e70d94-62ae-4530-bbdc-889824e7ec86','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_6aed087c-4630-4f06-b360-a333a600df62','','62.jpg','','',NULL,0,NULL,'2025-06-03 10:08:48','2025-06-03 10:08:48','',0),('2fdfe27d-cabf-4bf0-9013-29b78102ff73','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_17fd5705-45bc-4634-ab01-a91824c60c56','','943-hai_an-da_hai-ren_ti_nei_de_shui-re_dai_de_qu-hai_yang-x750.png','','',NULL,0,NULL,'2025-06-03 10:08:40','2025-06-03 10:08:40','',0),('38394c2d-5ee8-4954-9b23-1498820dfce6','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602115333.png','','','','',5,0,NULL,'2025-06-04 03:24:15','2025-06-04 03:24:15','',0),('3c2e5447-545e-4d7f-9ff4-a160b4abc393','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441327_1s_%E6%88%AA%E5%9B%BE20250602113601.png','','','','',5,0,NULL,'2025-06-04 03:24:14','2025-06-04 03:24:14','',0),('4957aa10-abfa-4228-af47-31a1dee5a4ad','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_8ca7b152-c625-421b-b957-7b1eda953454','','91.jpg','','',NULL,0,NULL,'2025-06-03 10:08:57','2025-06-03 10:08:57','',0),('5420a09b-b26b-4c89-9ecd-483e98844dde','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_79573143-cb75-45a5-ba74-641551c3f2e0','','150.jpg','','',NULL,0,NULL,'2025-06-03 10:09:01','2025-06-03 10:09:01','',0),('57eedbc6-a9b1-44b8-8d82-f1a3dbb6aed6','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_f4ab261a-81e1-4262-884b-fa995c9d191a','','58.jpg','','',NULL,0,NULL,'2025-06-03 10:08:50','2025-06-03 10:08:50','',0),('589d14f1-8855-4eea-9ae2-0e0164f16236','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_9e415fdb-312e-49da-9805-1376d9b5d210','','截图20250602150856.png','','',NULL,0,NULL,'2025-06-03 10:08:31','2025-06-03 10:08:31','',0),('591140cc-7411-4e09-a5e5-44af213df666','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_7e18b08b-e226-43d3-b8a8-cb29e0e5f11f','','112 (2).png','','',NULL,0,NULL,'2025-06-03 10:08:40','2025-06-03 10:08:40','',0),('592eff36-7762-44f4-b1c0-249589636fc5','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_f9891116-38d2-4beb-917d-39fdb9cb5b9e','','63.jpg','','',NULL,0,NULL,'2025-06-03 10:08:49','2025-06-03 10:08:49','',0),('5c104cba-d700-4a96-a085-9ad91d043abb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_157c92ce-c0c6-4249-9875-26e58898c65c','','77.jpg','','',NULL,0,NULL,'2025-06-03 10:08:54','2025-06-03 10:08:54','',0),('60722054-db93-452f-96b8-337b5379d7ac','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750123258704_1s_TCom_Fabric_Wool7_header.jpg','','','','',5,0,NULL,'2025-06-17 01:21:00','2025-06-17 14:20:24','',1),('61325860-49e8-4df3-aad7-b35150f60f58','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_5f9f3ffd-53a2-42e1-a5fe-e1b19406447e','','截图20250603153953.png','','',NULL,0,NULL,'2025-06-03 10:08:39','2025-06-03 10:08:39','',0),('6360fcf7-4cf9-473c-ab95-7af6da87d9c5','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_c2e4e83a-9701-452f-b267-fd1da8231cc9','','86.jpg','','',NULL,0,NULL,'2025-06-03 10:08:55','2025-06-03 10:08:55','',0),('64fc9eef-a3e2-4e29-9029-8d1bce9d3bee','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_e65f6d13-5760-40f3-b642-0f08fb30964c','','1.jpg','','',NULL,0,NULL,'2025-06-03 10:08:47','2025-06-03 10:08:47','',0),('65a8c9e8-5a6c-4827-9f74-f58be8f8200a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_8d5710cc-c7be-488f-9525-f547d815e5c1','','73.jpg','','',NULL,0,NULL,'2025-06-03 10:08:53','2025-06-03 10:08:53','',0),('683115d5-e3bd-44dd-9bcf-39ece92b1704','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_45840011-6505-408b-b6eb-b5f15c445b81','','截图20250602135930.png','','',NULL,0,NULL,'2025-06-03 10:08:30','2025-06-03 10:08:30','',0),('6c0936de-4d61-465c-9f4f-52c0fc4255ee','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441329_1s_%E6%88%AA%E5%9B%BE20250602135712.png','','','','',5,0,NULL,'2025-06-04 03:24:12','2025-06-04 03:24:12','',0),('73211a66-fb7e-4f85-a67b-861882ebd5a2','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_5eb88d72-79c1-407b-a9f5-91d4ebd95701','','32 (1).png','','',NULL,0,NULL,'2025-06-03 10:08:24','2025-06-03 10:08:24','',0),('734f0943-c0c7-4572-9de0-3640026e32a7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312252_1s_68cc4c06-c217-4e67-9831-3052b349b11c','','172894-sai_bo_peng_ke_2077_yi_shu-pang_ke2077-yi_shu-pang_ke-gai_nian_yi_shu-500x.png','','',NULL,0,NULL,'2025-06-03 10:08:22','2025-06-03 10:08:22','',0),('78722eb3-6d6f-4d80-aaaa-3e066b7c8caa','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_787261d7-61fe-4e3a-ada8-db1b9f5edf3d','','50.jpg','','',NULL,0,NULL,'2025-06-03 10:08:45','2025-06-03 10:08:45','',0),('78a80fc4-5ddb-4278-9cdb-ef11ffc9abe5','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_b1f4a5a1-c824-48e5-ac5d-265c7d29033c','','Image_fx (6).png','','',NULL,0,NULL,'2025-06-03 10:08:42','2025-06-03 10:08:42','',0),('796a6d6d-8842-4a47-9899-5e55e627659d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602151032.png','','','','',5,0,NULL,'2025-06-04 03:24:23','2025-06-04 03:24:23','',0),('7e033461-738b-4596-840f-16e7744bb79c','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312257_1s_45c5eb7f-fefe-4032-916b-8dc66920ee0e','','Image_fx (2).png','','',NULL,0,NULL,'2025-06-03 10:08:25','2025-06-03 10:08:25','',0),('7fa268b3-0c93-46cb-bb6d-59f6bf6f8f46','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_aa7c7b1e-5dfe-4e9f-b1bd-3c8184bc818b','','Image_fx.png','','',NULL,0,NULL,'2025-06-03 10:08:43','2025-06-03 10:08:43','',0),('8226845f-b985-4cd0-91c6-3a6fa248e8cb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_b6d3db85-2e01-41c7-8132-8bfae8f9f39e','','20.jpg','','',NULL,0,NULL,'2025-06-03 10:08:59','2025-06-03 10:08:59','',0),('83874c13-7572-4db1-8f95-874a070db56d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_d5a6f47c-b9e7-4e93-b9b4-e17f4fd8e628','','57.jpg','','',NULL,0,NULL,'2025-06-03 10:08:47','2025-06-03 10:08:47','',0),('844a65ac-cab7-47f6-be0d-4be16e4c70a6','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_de9533ce-5404-44de-a28b-20564d661055','','175607-yi_shu-pang_ke2077-shu_ma_yi_shu-pang_ke-xiang_su-500x.png','','',NULL,0,NULL,'2025-06-03 10:08:40','2025-06-03 10:08:40','',0),('8629afe1-fbb7-4a5d-8d9a-6247ab7b42a3','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_4f19b54d-9631-4f6e-b257-3399de39dc70','','截图20250602155625.png','','',NULL,0,NULL,'2025-06-03 10:08:32','2025-06-03 10:08:32','',0),('89a8bc2b-a0c5-48ff-b9fd-e82167826e8a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_b7317294-b6fe-4ef3-ba01-b132f89c18c4','','截图20250602111658.png','','',NULL,0,NULL,'2025-06-03 10:08:24','2025-06-03 10:08:24','',0),('8a2f9e14-58a5-48ba-9f7c-e94b107061ed','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_c1fe9669-a9fe-4f80-b61d-049d630a21a8','','Image_fx (4).png','','',NULL,0,NULL,'2025-06-03 10:08:27','2025-06-03 10:08:27','',0),('8d042a5e-9584-496e-945c-60b8421147ed','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_cb4963d1-716f-4f92-ba19-9d2ae592acd0','','89.jpg','','',NULL,0,NULL,'2025-06-03 10:08:56','2025-06-03 10:08:56','',0),('9162c5f9-2f26-4151-8649-dfeac74fd0cf','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602150856.png','','','','',5,0,NULL,'2025-06-04 03:24:24','2025-06-04 03:24:24','',0),('919878e7-0d5f-45e8-95be-95dd0c5b7074','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750463647542_1s_1174949_js_react%20js_logo_react_react%20native_icon.svg','','react','','',5,0,NULL,'2025-06-20 23:54:14','2025-06-20 23:54:14','',0),('95bf9363-b1a8-4b2c-8e4a-aaf27e3752a6','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602135930.png','','','','',5,0,NULL,'2025-06-04 03:24:19','2025-06-04 03:24:19','',0),('9686dbd6-a331-43c5-8340-88b3f5bec445','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_d62782e3-be12-405c-a2dc-c2c62aa36a95','','截图20250602111041.png','','',NULL,0,NULL,'2025-06-03 10:08:25','2025-06-03 10:08:25','',0),('9a1f8af4-68e8-46a4-a778-62fb1f846bb8','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_5c978ee8-8b75-484b-9656-3810a5557a42','','66.jpg','','',NULL,0,NULL,'2025-06-03 10:08:50','2025-06-03 10:08:50','',0),('9a9c1ab9-9153-40f6-b5cd-f00a347c5156','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_455dcbd6-8854-4a37-987c-5f2291ee95f1','','38.jpg','','',NULL,0,NULL,'2025-06-03 10:09:03','2025-06-03 10:09:03','',0),('9ad95dab-702e-48ca-9fb1-d2331405bf1f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_cf46ec75-2f43-47c5-92a4-72547e169408','','112 (1).png','','',NULL,0,NULL,'2025-06-03 10:08:39','2025-06-03 10:08:39','',0),('a275cc8f-850f-47da-a337-d7046e562c27','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312256_1s_e22941a0-d29f-4055-8598-a6fb9cccccf9','','70779-ou_tie_man_nu-tian_kong-yan_hai_he_hai_yang_de_mao-du_jia_cun-bie_shu-500x.png','','',NULL,0,NULL,'2025-06-03 10:08:22','2025-06-03 10:08:22','',0),('a3ba9489-6439-4fee-a457-5e9c6f968eec','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_236ccbf6-27fb-4008-9052-32bdeaa01a14','','121.jpg','','',NULL,0,NULL,'2025-06-03 10:09:00','2025-06-03 10:09:00','',0),('ac929005-3a07-4c8a-95db-6f79081e3494','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750124735570_1s_dense-rattan-599-mm-architextures.jpg','','','','',5,0,NULL,'2025-06-17 01:45:35','2025-06-17 09:35:05','',1),('ad050e85-dcb2-441f-b2f1-1bd45f46fd68','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_5aaf131a-c71f-40d3-b54c-be2a2db2b5cd','','105.jpg','','',NULL,0,NULL,'2025-06-03 10:08:59','2025-06-03 10:08:59','',0),('ad886d42-5d49-4c1a-bdd9-739130e969b1','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750462867744_1s_Vue_idrkKugrkm_0.png','','vue png','','',5,0,NULL,'2025-06-20 23:41:09','2025-06-20 23:41:09','',0),('adfb6704-5718-4368-8ea7-63e1872c43f0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_ef085b7d-86df-4b2d-aa5d-295d133695d8','','截图20250602150538.png','','',NULL,0,NULL,'2025-06-03 10:08:30','2025-06-03 10:08:30','',0),('afb247e1-95a5-4f45-a030-19af411e4790','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_e313c43f-aad6-4c72-989f-fbcf6a7ab880','','截图20250602140317.png','','',NULL,0,NULL,'2025-06-03 10:08:29','2025-06-03 10:08:29','',0),('afc5229c-4582-476f-b96f-2a35c3e78480','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_45b01895-a0a2-48a3-80cd-3a2c81b667ab','','截图20250602155814.png','','',NULL,0,NULL,'2025-06-03 10:08:34','2025-06-03 10:08:34','',0),('b69f8160-d1c8-46a5-843c-ab8b8e48c3e2','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_14b35b58-373f-4958-b4e4-3c360dfe8cc9','','截图20250603153020.png','','',NULL,0,NULL,'2025-06-03 10:08:38','2025-06-03 10:08:38','',0),('bbe762cf-478e-4a5f-b3b2-2cba6fb885f7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602150933.png','','','','',5,0,NULL,'2025-06-04 03:24:30','2025-06-04 03:24:30','',0),('bc520497-efb9-429a-b24f-dbf39f68afda','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_95d98fe8-fdd7-4b83-a296-ffa0e0cbf0bc','','43.jpg','','',NULL,0,NULL,'2025-06-03 10:08:44','2025-06-03 10:08:44','',0),('c20d449b-3c6e-453f-ba7e-8882d116afa0','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_98f5d343-c1c1-4bc9-aba3-67c88390dfda','','71.jpg','','',NULL,0,NULL,'2025-06-03 10:08:51','2025-06-03 10:08:51','',0),('c2fb717d-ffdb-45de-b92d-3b460dee6d88','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_e27de861-75a1-4948-aaa3-209747079aee','','100.jpg','','',NULL,0,NULL,'2025-06-03 10:08:58','2025-06-03 10:08:58','',0),('c4f98c88-a2a5-4056-9e0a-4a6d9881ab40','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748867414584_1s_%E7%94%A8%E7%A0%94.svg','','','','',5,0,NULL,'2025-06-02 12:30:16','2025-06-02 12:30:16','',0),('c7ca9d4f-f4c3-4d19-842e-5b5709a03874','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_a4edd886-0867-45c4-b868-cfe6035cdcb0','','69.jpg','','',NULL,0,NULL,'2025-06-03 10:08:51','2025-06-03 10:08:51','',0),('c8ca63ba-70cf-4e93-bd8f-2b469513f882','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441320_1s_Image_fx%20%285%29.png','','','','',5,0,NULL,'2025-06-04 03:24:09','2025-06-04 03:24:09','',0),('c9fa7b61-770a-4f3f-991a-13f7c85aae6c','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_39d83547-32ae-435d-b71a-2f17c016ec5b','','44.jpg','','',NULL,0,NULL,'2025-06-03 10:08:45','2025-06-03 10:08:45','',0),('cc7899b5-920c-4f55-90ad-377cfa0a3788','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_e0d30209-37be-4d66-9ef3-7d8f6266927c','','截图20250603153205.png','','',NULL,0,NULL,'2025-06-03 10:08:38','2025-06-03 10:08:38','',0),('cd8252a7-c74a-44c8-bdfe-ca7655123530','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602150538.png','','','','',5,0,NULL,'2025-06-04 03:24:19','2025-06-04 03:24:19','',0),('d22ad2ae-cf24-40d9-b82c-c3a047e0540f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_25e8af64-53d4-4cf6-b2bc-3626b5c53297','','截图20250603153934.png','','',NULL,0,NULL,'2025-06-03 10:08:38','2025-06-03 10:08:38','',0),('d9acab4c-3419-4367-b69f-aa9e6791dd94','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_b5f409bb-06cc-4a04-a10c-41bcfc090dfa','','152.jpg','','',NULL,0,NULL,'2025-06-03 10:09:02','2025-06-03 10:09:02','',0),('daa17f9b-47d4-4d4f-aa4d-9058172bc840','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_720bad3f-3492-47a5-9334-038619062350','','截图20250603151855.png','','',NULL,0,NULL,'2025-06-03 10:08:36','2025-06-03 10:08:36','',0),('dae7cf23-df73-46a2-beeb-87806f5fab03','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_78522538-1673-49b2-a904-808d3f79f92d','','42.jpg','','',NULL,0,NULL,'2025-06-03 10:09:01','2025-06-03 10:09:01','',0),('db85d7a2-399a-4940-b0c9-35a0803c6585','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_fd159437-8b7c-4c98-92d1-32616285684c','','64.jpg','','',NULL,0,NULL,'2025-06-03 10:08:48','2025-06-03 10:08:48','',0),('dbb3e589-b688-4465-b4da-6ecf46faf70f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_c5cad426-edeb-4f3d-8d8d-3b2604dc5748','','截图20250602154328.png','','',NULL,0,NULL,'2025-06-03 10:08:33','2025-06-03 10:08:33','',0),('dd23544c-09df-4762-a7f7-b111c8b6c690','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_be618460-38f0-4d8b-b5f1-522681518501','','115.jpg','','',NULL,0,NULL,'2025-06-03 10:08:59','2025-06-03 10:08:59','',0),('e04ac244-f704-456f-8dd5-a7ec5c8fe935','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_b6266441-14b4-4aa7-9bcc-61620f55ce3d','','87.jpg','','',NULL,0,NULL,'2025-06-03 10:08:56','2025-06-03 10:08:56','',0),('e48e329d-8c3d-4cd0-9c0c-6a10aa848d69','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_132c1e2c-6b19-443e-8492-4a554d03cc5a','','截图20250603152008.png','','',NULL,0,NULL,'2025-06-03 10:08:36','2025-06-03 10:08:36','',0),('e504494b-5905-4dd3-a106-424466f843c7','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750414613079_1s_vue-js-seeklogo.svg','vue,程序员','vue logo','','vue 是一个知名框架',5,0,NULL,'2025-06-20 10:16:46','2025-06-20 10:16:46','',0),('e62a97b8-59e6-4c17-9d9c-7cc318223621','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_94cfd6f6-a98d-487e-b5aa-d87d31f5b024','','截图20250602135712.png','','',NULL,0,NULL,'2025-06-03 10:08:28','2025-06-03 10:08:28','',0),('e6b2e74b-19c4-479c-a445-fd2dafe94edb','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1750462770829_1s_Vue_idrkKugrkm_1.svg','vue','vue logo','','vue 是一个前端框架',5,0,NULL,'2025-06-20 23:39:32','2025-06-20 23:39:32','',0),('e83c8a76-0d5f-4e0e-97a6-63daa3e63509','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_e46eab9f-855a-4d7e-8515-998c9344d0a2','','Image_fx (5).png','','',NULL,0,NULL,'2025-06-03 10:08:26','2025-06-03 10:08:26','',0),('e934e1b6-9b6f-4526-8b14-50a17b4a7b67','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_4751438c-17ef-401a-87c6-33f8274346ef','','70.jpg','','',NULL,0,NULL,'2025-06-03 10:08:51','2025-06-03 10:08:51','',0),('e993abf1-2e13-4436-ae60-19ff8d049add','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_66f100c1-1248-46f6-b543-b73bd36eb55a','','76.jpg','','',NULL,0,NULL,'2025-06-03 10:08:53','2025-06-03 10:08:53','',0),('e9ac8ba3-0741-4439-8df7-3a96bff32fc9','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1749007441330_1s_%E6%88%AA%E5%9B%BE20250602140317.png','','','','',5,0,NULL,'2025-06-04 03:24:19','2025-06-04 03:24:19','',0),('eaeeef80-563a-407f-87b1-da4c8d03970a','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_a6620ab1-86f6-4cac-9145-56c184e0ce0a','','截图20250602155733.png','','',NULL,0,NULL,'2025-06-03 10:08:33','2025-06-03 10:08:33','',0),('ecd80115-a0d8-40db-94da-56c309564546','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_8e416142-2c5c-4734-9c25-afdd5981dfd9','','截图20250602115333.png','','',NULL,0,NULL,'2025-06-03 10:08:29','2025-06-03 10:08:29','',0),('ed774922-add2-49b2-ae1a-5d8a3a632e9d','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_676cd8b2-025f-4ef2-b4a4-60f9bfa25771','','53.jpg','','',NULL,0,NULL,'2025-06-03 10:08:47','2025-06-03 10:08:47','',0),('f210ee08-3481-4576-81ed-364f6b968aad','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_c22ed587-5a8d-4749-8492-2bd57d221fb5','','截图20250602150933.png','','',NULL,0,NULL,'2025-06-03 10:08:32','2025-06-03 10:08:32','',0),('f2a49d96-e556-42e1-8463-e2e9e73a0232','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_8b06b342-c55d-48b6-895c-d09de8536057','','40.jpg','','',NULL,0,NULL,'2025-06-03 10:08:44','2025-06-03 10:08:44','',0),('f2abd838-8e3c-4777-869c-3dbc8064338f','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312258_1s_e3b20c6d-7ab1-473d-992d-d5a2ad0a1abc','','截图20250602113601.png','','',NULL,0,NULL,'2025-06-03 10:08:26','2025-06-03 10:08:26','',0),('f33d91a6-a235-42ee-a733-dbadd0da3934','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312259_1s_c19fa203-d5a6-45af-b672-a54eb957556e','','52.jpg','','',NULL,0,NULL,'2025-06-03 10:08:45','2025-06-03 10:08:45','',0),('f5e23fdb-237c-400c-9a57-6546222ca04e','https://1s-1257307499.cos.ap-beijing.myqcloud.com/1748945312260_1s_93a75a34-e1d3-4f41-9ed4-09a502dd8f3e','','93.jpg','','',NULL,0,NULL,'2025-06-03 10:08:57','2025-06-03 10:08:57','',0);
/*!40000 ALTER TABLE `sticker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `phone` bigint(20) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `isAdmin` tinyint(4) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `avatar` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (5,'jackie','jackie',NULL,NULL,NULL,NULL,NULL,'$2a$10$tPfIAPO/N1OUoXF4RzoTbOG.BAE.dyYTKiyJmq9Po3g685I74GUBu','{}','','','2025-05-29 23:49:04','2025-06-05 10:45:15');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-26 16:22:11
